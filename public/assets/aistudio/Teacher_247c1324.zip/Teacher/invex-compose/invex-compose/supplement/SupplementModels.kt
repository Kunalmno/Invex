package com.invex.app.supplement

/** A student who can be issued a sheet (the searchable list in the sign sheet). */
data class RosterStudent(
    val id: String,
    val name: String,
    val course: String,
    val year: String,
    val rollNumber: String,
) {
    val meta: String get() = "$course | $year | $rollNumber"
}

/** A row of the "Sheets Issued" list: one per student, with a running sheet count. */
data class StudentSheet(
    val id: String,
    val name: String,
    val course: String,
    val year: String,
    val rollNumber: String,
    val sheetCount: Int,
    val status: SheetStatus,
) {
    val meta: String get() = "$course | $year | $rollNumber"
}

// Only RESOLVED is shown in the Figma frame; PENDING is used for a freshly issued sheet.
enum class SheetStatus(val label: String) {
    RESOLVED("Resolved"),
    PENDING("Pending"),
}

data class SheetSummary(
    val issued: Int = 0,
    val awaitingReturn: Int = 0,
    val returned: Int = 0,
    val inStock: Int = 0,
)
