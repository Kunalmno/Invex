package com.invex.app.supplement

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SupplementUiState(
    val summary: SheetSummary = SheetSummary(),
    val query: String = "",
    val roster: List<RosterStudent> = emptyList(),
    val allStudents: List<StudentSheet> = emptyList(),
) {
    val visibleStudents: List<StudentSheet>
        get() = if (query.isBlank()) allStudents else allStudents.filter {
            it.name.contains(query, ignoreCase = true) ||
                it.rollNumber.contains(query, ignoreCase = true) ||
                it.course.contains(query, ignoreCase = true)
        }
}

class SupplementViewModel : ViewModel() {

    // Sample data. The first three students are the ones already in "Sheets Issued".
    private val sampleRoster = listOf(
        RosterStudent("s0", "Lorem Ipsum Dorem", "B.tech", "3rd Year", "7045"),
        RosterStudent("s1", "Lorem Ipsum Dorem", "B.tech", "3rd Year", "7046"),
        RosterStudent("s2", "Lorem Ipsum Dorem", "B.tech", "3rd Year", "7047"),
        RosterStudent("s3", "Aarav Sharma", "B.tech", "2nd Year", "6120"),
        RosterStudent("s4", "Diya Patel", "B.tech", "3rd Year", "7102"),
        RosterStudent("s5", "Rohan Mehta", "M.tech", "1st Year", "3311"),
    )

    private val _state = MutableStateFlow(
        SupplementUiState(
            summary = SheetSummary(issued = 1, awaitingReturn = 15, returned = 1, inStock = 1),
            roster = sampleRoster,
            allStudents = sampleRoster.take(3).map {
                StudentSheet(
                    id = it.id,
                    name = it.name,
                    course = it.course,
                    year = it.year,
                    rollNumber = it.rollNumber,
                    sheetCount = 1,
                    status = SheetStatus.RESOLVED,
                )
            },
        )
    )
    val state: StateFlow<SupplementUiState> = _state.asStateFlow()

    fun onQueryChange(query: String) = _state.update { it.copy(query = query) }

    /**
     * Issues one more sheet to a student. Product rule: a repeat request increments the
     * student's number instead of adding a row. Request metadata (time, signer) is stored
     * by the backend, so there is nothing to keep here.
     */
    fun issueSheet(studentId: String) = _state.update { s ->
        val student = s.roster.firstOrNull { it.id == studentId } ?: return@update s
        val alreadyListed = s.allStudents.any { it.id == studentId }
        val students = if (alreadyListed) {
            s.allStudents.map { if (it.id == studentId) it.copy(sheetCount = it.sheetCount + 1) else it }
        } else {
            listOf(
                StudentSheet(
                    id = student.id,
                    name = student.name,
                    course = student.course,
                    year = student.year,
                    rollNumber = student.rollNumber,
                    sheetCount = 1,
                    status = SheetStatus.PENDING,
                )
            ) + s.allStudents
        }
        s.copy(
            allStudents = students,
            summary = s.summary.copy(
                issued = s.summary.issued + 1,
                inStock = (s.summary.inStock - 1).coerceAtLeast(0),
            ),
        )
    }
}
