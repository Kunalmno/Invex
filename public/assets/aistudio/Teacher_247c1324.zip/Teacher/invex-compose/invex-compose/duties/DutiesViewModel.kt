package com.invex.app.duties

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class DutiesViewModel : ViewModel() {

    private val _state = MutableStateFlow(DutiesUiState())
    val state: StateFlow<DutiesUiState> = _state.asStateFlow()

    fun onTabSelected(tab: DutiesTab) {
        _state.update { it.copy(selectedTab = tab) }
    }
}
