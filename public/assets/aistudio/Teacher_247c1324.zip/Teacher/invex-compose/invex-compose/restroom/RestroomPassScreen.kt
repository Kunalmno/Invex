package com.invex.app.restroom

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.invex.app.ui.theme.InvexTheme
import com.invex.app.ui.theme.InvexType
import com.invex.app.ui.theme.MobileBackground

/**
 * Stateful container for RestroomPassScreen. Owns and drives the [RestroomPassViewModel].
 */
@Composable
fun RestroomPassRoute(
    onBack: () -> Unit,
    viewModel: RestroomPassViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    RestroomPassScreen(
        state = state,
        onBack = onBack,
        onIssuePassClick = viewModel::onIssuePassClick,
        onReportClick = viewModel::onReportClick,
        onInfoClick = viewModel::onInfoClick,
        onDownloadClick = viewModel::onDownloadClick,
        onDismissReportDialog = viewModel::onDismissReportDialog,
        onConfirmReport = viewModel::onConfirmReport,
    )
}

/**
 * Stateless Restroom Pass management screen displaying summary indicators,
 * issuance action, an active pass ticket card with live countdown, and recent pass history.
 */
@Composable
fun RestroomPassScreen(
    state: RestroomUiState,
    onBack: () -> Unit,
    onIssuePassClick: () -> Unit,
    onReportClick: () -> Unit,
    onInfoClick: () -> Unit,
    onDownloadClick: () -> Unit,
    onDismissReportDialog: () -> Unit,
    onConfirmReport: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MobileBackground)
            .statusBarsPadding(),
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            // 1. Screen Header
            item(key = "header") {
                RestroomHeader(onBack = onBack)
            }

            // 2. Summary Status Cards Row (Out, Returned, Overdue)
            item(key = "status_row") {
                PassesStatusRow(summary = state.summary)
            }

            // 3. Main Action CTA Button
            item(key = "issue_button") {
                IssuePassButton(
                    onClick = onIssuePassClick,
                    label = "Issue a Supplementary Sheet", // Replicates Figma mockup text (configurable)
                )
            }

            // 4. Active Pass Section
            item(key = "active_pass_heading") {
                Text(
                    text = "Active Pass",
                    style = InvexType.SectionHeadingBold,
                    color = Color.Black,
                )
            }

            if (state.activePass != null) {
                item(key = "active_pass_card") {
                    ActivePassCard(
                        pass = state.activePass,
                        onReport = onReportClick,
                        onInfo = onInfoClick,
                        onDownload = onDownloadClick,
                    )
                }
            }

            // 5. Recent Pass Section
            item(key = "recent_pass_heading") {
                Text(
                    text = "Recent Pass",
                    style = InvexType.SectionHeadingBold,
                    color = Color.Black,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }

            items(
                items = state.recentPasses,
                key = { it.id },
            ) { passItem ->
                RecentPassCard(item = passItem)
            }

            item(key = "bottom_spacer") {
                Spacer(Modifier.height(16.dp))
            }
        }

        // Report confirmation dialog
        if (state.showReportDialog) {
            ReportStudentDialog(
                studentName = state.activePass?.studentName ?: "Student",
                onConfirm = onConfirmReport,
                onDismiss = onDismissReportDialog,
            )
        }
    }
}

@Preview(showBackground = true, widthDp = 390, heightDp = 920)
@Composable
fun RestroomPassScreenPreview() {
    InvexTheme {
        RestroomPassScreen(
            state = RestroomUiState(),
            onBack = {},
            onIssuePassClick = {},
            onReportClick = {},
            onInfoClick = {},
            onDownloadClick = {},
            onDismissReportDialog = {},
            onConfirmReport = {},
        )
    }
}
