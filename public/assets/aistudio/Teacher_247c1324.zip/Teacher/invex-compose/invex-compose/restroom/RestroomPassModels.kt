package com.invex.app.restroom

/** Summary counts shown at the top of the Restroom Pass screen. */
data class PassSummary(
    val out: Int = 1,
    val returned: Int = 15,
    val overdue: Int = 1,
)

/** Active in-flight restroom pass displayed inside the ticket card. */
data class ActivePass(
    val studentName: String = "John Doe",
    val seat: String = "A2",
    val regNo: String = "7890",
    val course: String = "B. tech",
    val leftHallAt: String = "09:00",
    val elapsedAt: String = "09:15",
    val durationLabel: String = "15 Minutes",
    val remainingSeconds: Long = 900L,
    val validUntil: String = "Valid Until 01 Jan 27 09:15:00",
    val serialNumber: String = "No . 1234567890",
    val isActive: Boolean = true,
) {
    /** Formats remaining seconds as "15 minutes 00 second" matching Figma mockup. */
    val remainingFormatted: String
        get() {
            val minutes = remainingSeconds / 60
            val seconds = remainingSeconds % 60
            return "%d minutes %02d second".format(minutes, seconds)
        }
}

/** Historical item displayed in the "Recent Pass" feed. */
data class RecentPassItem(
    val id: String,
    val studentName: String = "Lorem Ipsum",
    val status: String = "Returned",
    val validUntil: String = "Valid Until 01 Jan 26",
    val duration: String = "5 min",
    val timeRange: String = "09:00 AM - 09:15 AM",
    val isReturned: Boolean = true, // true = ic_returned (check), false = ic_notreturned (alert)
)

/** Full UI state for the Restroom Pass screen. */
data class RestroomUiState(
    val summary: PassSummary = PassSummary(),
    val activePass: ActivePass? = ActivePass(),
    val recentPasses: List<RecentPassItem> = listOf(
        RecentPassItem(
            id = "1",
            studentName = "Lorem Ipsum",
            status = "Returned",
            validUntil = "Valid Until 01 Jan 26",
            duration = "5 min",
            timeRange = "09:00 AM - 09:15 AM",
            isReturned = true,
        ),
        RecentPassItem(
            id = "2",
            studentName = "Lorem Ipsum",
            status = "Returned",
            validUntil = "Valid Until 01 Jan 26",
            duration = "5 min",
            timeRange = "09:00 AM - 09:15 AM",
            isReturned = false,
        ),
    ),
    val showReportDialog: Boolean = false,
    val toastMessage: String? = null,
)
