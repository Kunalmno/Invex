package com.invex.app.restroom

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class RestroomPassViewModel : ViewModel() {

    private val _state = MutableStateFlow(RestroomUiState())
    val state: StateFlow<RestroomUiState> = _state.asStateFlow()

    private var timerJob: Job? = null

    init {
        startCountdownTimer()
    }

    private fun startCountdownTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                _state.update { current ->
                    val active = current.activePass ?: return@update current
                    if (active.remainingSeconds > 0) {
                        current.copy(
                            activePass = active.copy(
                                remainingSeconds = active.remainingSeconds - 1,
                            ),
                        )
                    } else {
                        // When timer reaches 0, pass becomes overdue
                        current.copy(
                            summary = current.summary.copy(
                                out = (current.summary.out - 1).coerceAtLeast(0),
                                overdue = current.summary.overdue + 1,
                            ),
                        )
                    }
                }
            }
        }
    }

    fun onIssuePassClick() {
        _state.update {
            it.copy(toastMessage = "Issue pass dialog opened")
        }
    }

    fun onReportClick() {
        _state.update { it.copy(showReportDialog = true) }
    }

    fun onDismissReportDialog() {
        _state.update { it.copy(showReportDialog = false) }
    }

    fun onConfirmReport(reason: String) {
        _state.update {
            it.copy(
                showReportDialog = false,
                toastMessage = "Student reported to invigilator runner",
            )
        }
    }

    fun onInfoClick() {
        _state.update {
            it.copy(toastMessage = "Pass validity: 15-minute standard hall leave")
        }
    }

    fun onDownloadClick() {
        _state.update {
            it.copy(toastMessage = "Downloading digital pass slip...")
        }
    }

    fun clearToast() {
        _state.update { it.copy(toastMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
