package com.invex.app.examdetails

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Read-only for now: sample data stands in for the backend. Nothing on this screen edits state. */
class ExamDetailsViewModel : ViewModel() {
    private val _state = MutableStateFlow(ExamDetailsUiState())
    val state: StateFlow<ExamDetailsUiState> = _state.asStateFlow()
}
