package com.invex.app.examdetails

import androidx.annotation.DrawableRes
import com.invex.app.R

data class ExamCourse(
    val id: String,
    val label: String,      // small line above the name, "Course I"
    val name: String,
    val students: Int,
)

data class RoomInfo(
    val block: String,
    val room: String,
    val division: String,
)

/** The four service buttons. Labels use the corrected spelling ("Supplement Sheet"). */
enum class ExamService(val label: String, @DrawableRes val iconRes: Int) {
    VERIFY_ADMIT_CARD("Verify\nAdmit Card", R.drawable.ic_service_admit_card),
    SUPPLEMENT_SHEET("Supplement\nSheet", R.drawable.ic_service_supplement_sheet),
    RESTROOM_PASS("Restroom\nPass", R.drawable.ic_service_restroom_pass),
    ATTENDANCE("Attendance", R.drawable.ic_service_attendance),
}

data class ExamDetailsUiState(
    val courses: List<ExamCourse> = listOf(
        ExamCourse("1", "Course I", "Lorem Ipsum Dorem", 10),
        ExamCourse("2", "Course I", "Lorem Ipsum Dorem", 10),
        ExamCourse("3", "Course I", "Lorem Ipsum Dorem", 10),
        ExamCourse("4", "Course I", "Lorem Ipsum Dorem", 10),
    ),
    val room: RoomInfo = RoomInfo(block = "A", room = "317", division = "B"),
)
