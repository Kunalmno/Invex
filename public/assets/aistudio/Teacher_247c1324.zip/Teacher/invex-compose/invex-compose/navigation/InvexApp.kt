package com.invex.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.invex.app.attendance.AttendanceRoute
import com.invex.app.dashboard.DashboardNavTab
import com.invex.app.dashboard.DashboardRoute
import androidx.navigation.NavController
import com.invex.app.duties.DutiesRoute
import com.invex.app.accountinfo.AccountInfoRoute
import com.invex.app.notifications.NotificationsRoute
import com.invex.app.schedule.ScheduleRoute
import com.invex.app.settings.SettingsItem
import com.invex.app.settings.SettingsScreen
import com.invex.app.examdetails.ExamDetailsRoute
import com.invex.app.examdetails.ExamService
import com.invex.app.verifyadmit.VerifyAdmitRoute
import com.invex.app.login.LoginRoute
import com.invex.app.register.RegisterRoute
import com.invex.app.restroom.RestroomPassRoute
import com.invex.app.rooms.RoomsRoute
import com.invex.app.onboarding.OnboardingScreen
import com.invex.app.supplement.SupplementSheetRoute

object Route {
    const val Onboarding  = "onboarding"
    const val Login       = "login"
    const val Register    = "register"
    const val Dashboard   = "dashboard"
    const val Duties      = "duties"
    const val Schedule    = "schedule"
    const val Settings    = "settings"
    const val AccountInfo = "account_info"
    const val Notifications = "notifications"
    const val ExamDetails = "exam_details"
    const val VerifyAdmit = "verify_admit"
    const val Attendance  = "attendance"
    const val Supplement  = "supplement"
    const val RestroomPass = "restroom_pass"
    const val RoomView    = "room_view"
}

/**
 * App navigation. Onboarding (Skip or Start) always goes to Login, and Onboarding is removed from the
 * back stack so Back from Login leaves the app instead of returning to the intro.
 *
 * Needs: implementation("androidx.navigation:navigation-compose:<version>")
 */
@Composable
fun InvexApp(
    onExit: () -> Unit = {},
    startDestination: String = Route.Onboarding,
) {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = startDestination,
        modifier = Modifier,
    ) {
        composable(Route.Onboarding) {
            OnboardingScreen(
                onFinished = {
                    nav.navigate(Route.Login) {
                        popUpTo(Route.Onboarding) { inclusive = true }
                    }
                },
            )
        }
        composable(Route.Login) {
            LoginRoute(
                onLoggedIn = {
                    nav.navigate(Route.Dashboard) {
                        popUpTo(Route.Login) { inclusive = true }
                    }
                },
                onSignUp = { nav.navigate(Route.Register) },
            )
        }
        composable(Route.Register) {
            RegisterRoute(
                onRegistered = {
                    nav.navigate(Route.Dashboard) {
                        popUpTo(Route.Register) { inclusive = true }
                    }
                },
                onSignIn = { nav.popBackStack() },
            )
        }
        composable(Route.Dashboard) {
            DashboardRoute(
                onNavigateToRooms = { nav.navigate(Route.RoomView) },
                onNavigateToAttendance = { nav.navigate(Route.Attendance) },
                onNavigateToDuties = { nav.navigate(Route.Duties) },
                onNavigateToSchedule = { nav.navigate(Route.Schedule) },
                onNavigateToSettings = { nav.navigate(Route.Settings) },
                onNavigateToExamDetails = { nav.navigate(Route.ExamDetails) },
            )
        }
        composable(Route.ExamDetails) {
            ExamDetailsRoute(
                onBack = { nav.popBackStack() },
                onProceed = { nav.navigate(Route.RoomView) },
                onService = { service ->
                    when (service) {
                        ExamService.SUPPLEMENT_SHEET -> nav.navigate(Route.Supplement)
                        ExamService.RESTROOM_PASS -> nav.navigate(Route.RestroomPass)
                        ExamService.ATTENDANCE -> nav.navigate(Route.Attendance)
                        ExamService.VERIFY_ADMIT_CARD -> nav.navigate(Route.VerifyAdmit)
                    }
                },
            )
        }
        composable(Route.VerifyAdmit) { VerifyAdmitRoute(onBack = { nav.popBackStack() }) }
        composable(Route.Settings) {
            SettingsScreen(
                onItemClick = { item ->
                    when (item) {
                        SettingsItem.ACCOUNT_INFORMATION -> nav.navigate(Route.AccountInfo)
                        SettingsItem.NOTIFICATIONS -> nav.navigate(Route.Notifications)
                    }
                },
                onLogOut = {
                    // Clear everything so Back cannot return to a logged-in screen.
                    nav.navigate(Route.Login) { popUpTo(0) { inclusive = true } }
                },
                onNavTab = { tab -> nav.goToTab(tab, current = DashboardNavTab.SETTINGS) },
            )
        }
        composable(Route.Notifications) { NotificationsRoute(onBack = { nav.popBackStack() }) }
        composable(Route.AccountInfo) { AccountInfoRoute(onBack = { nav.popBackStack() }) }
        composable(Route.Schedule) {
            ScheduleRoute(
                onBack = { nav.popBackStack() },
                onNavTab = { tab -> nav.goToTab(tab, current = DashboardNavTab.SCHEDULE) },
            )
        }
        composable(Route.Duties) {
            DutiesRoute(
                onBack = { nav.popBackStack() },
                onViewRoomSeating = { nav.navigate(Route.RoomView) },
                onNavTab = { tab -> nav.goToTab(tab, current = DashboardNavTab.DUTIES) },
            )
        }
        composable(Route.Attendance) { AttendanceRoute(onBack = { nav.popBackStack() }) }
        composable(Route.Supplement) { SupplementSheetRoute(onBack = { nav.popBackStack() }) }
        composable(Route.RestroomPass) { RestroomPassRoute(onBack = { nav.popBackStack() }) }
        composable(Route.RoomView) { RoomsRoute(onBack = { nav.popBackStack() }) }
    }
}

/** Bottom bar navigation shared by the tab screens. Keeps the back stack flat: Dashboard, then one tab screen. */
private fun NavController.goToTab(tab: DashboardNavTab, current: DashboardNavTab) {
    if (tab == current) return
    when (tab) {
        DashboardNavTab.HOME -> popBackStack(Route.Dashboard, inclusive = false)
        DashboardNavTab.DUTIES -> navigate(Route.Duties) {
            popUpTo(Route.Dashboard) { inclusive = false }
            launchSingleTop = true
        }
        DashboardNavTab.SCHEDULE -> navigate(Route.Schedule) {
            popUpTo(Route.Dashboard) { inclusive = false }
            launchSingleTop = true
        }
        DashboardNavTab.SETTINGS -> navigate(Route.Settings) {
            popUpTo(Route.Dashboard) { inclusive = false }
            launchSingleTop = true
        }
    }
}
