package com.invex.app.rooms

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.invex.app.ui.theme.InvexTheme
import com.invex.app.ui.theme.MobileBackground

// ── Stateful route ────────────────────────────────────────────────────────────

/**
 * Stateful entry-point for the Room View screen. Owns [RoomsViewModel].
 *
 * Call [viewModel].loadRoom() from the host before or after navigation to inject
 * real room data; the ViewModel defaults to "317 / B / OOPS" for preview use.
 */
@Composable
fun RoomsRoute(
    onBack: () -> Unit,
    viewModel: RoomsViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsState()
    RoomsScreen(
        state = state,
        onBack = onBack,
        onSeatClick = viewModel::onSeatClick,
    )
}

// ── Stateless screen ──────────────────────────────────────────────────────────

/**
 * Stateless Room View screen.
 *
 * Layout (top-to-bottom):
 * 1. [RoomsHeader]       — Back + icon badge + "Room" heading
 * 2. [RoomSubtitleLine]  — "Room : 317 | Block : B | Course : OOPS"
 * 3. [SeatGridCard]      — 7-row × 6-column pink seat tiles
 * 4. [CourseLegendGrid]  — 2 × 2 course legend cards
 */
@Composable
fun RoomsScreen(
    state: RoomsUiState,
    onBack: () -> Unit,
    onSeatClick: (SeatData) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MobileBackground)
            .statusBarsPadding(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 20.dp,
            bottom = 32.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 1. Header
        item(key = "header") {
            RoomsHeader(onBack = onBack)
        }

        // 2. Subtitle meta line
        item(key = "subtitle") {
            RoomSubtitleLine(info = state.roomInfo)
        }

        // 3. Seat grid card
        item(key = "seat_grid") {
            SeatGridCard(
                seats = state.seats,
                onSeatClick = onSeatClick,
            )
        }

        // 4. Course legend
        item(key = "course_legend") {
            CourseLegendGrid(courses = state.courses)
        }
    }
}

// ── Preview ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun RoomsScreenPreview() {
    InvexTheme {
        RoomsScreen(
            state = RoomsUiState(),
            onBack = {},
            onSeatClick = {},
        )
    }
}
