package com.invex.app.rooms

// ── Seat state ────────────────────────────────────────────────────────────────

/**
 * Visual state of a single seat tile.
 * Only [Assigned] is shown in the current mockup; the other states are reserved
 * for future colour-coding (absent, verified, flagged).
 */
enum class SeatState { Assigned, Empty, Absent, Verified }

/** A single seat in the grid, e.g. row = 'A', col = 1  → label "A1". */
data class SeatData(
    val row: Char,
    val col: Int,
    val state: SeatState = SeatState.Assigned,
) {
    val label: String get() = "$row$col"
}

// ── Room meta ─────────────────────────────────────────────────────────────────

/** High-level room information shown in the subtitle meta line. */
data class RoomInfo(
    val roomNumber: String = "317",
    val block: String = "B",
    val course: String = "OOPS",
)

/** A course entry shown in the legend at the bottom of the screen. */
data class CourseItem(val name: String)

// ── UI state ──────────────────────────────────────────────────────────────────

/** Full UI state for the Room View screen. */
data class RoomsUiState(
    val roomInfo: RoomInfo = RoomInfo(),
    val seats: List<SeatData> = defaultSeats(),
    val courses: List<CourseItem> = listOf(
        CourseItem("Course 1"),
        CourseItem("Course 2"),
        CourseItem("Course 3"),
        CourseItem("Course 4"),
    ),
)

/**
 * Builds the default 7-row × 6-column seat layout matching the mockup.
 * Row F is intentionally absent (matches the design screenshot).
 */
fun defaultSeats(): List<SeatData> {
    val rows = listOf('A', 'B', 'C', 'D', 'E', 'G') // F row skipped per mockup
    val cols = 1..6
    return rows.flatMap { row -> cols.map { col -> SeatData(row, col) } }
}
