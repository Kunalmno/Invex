package com.invex.app.rooms

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class RoomsViewModel : ViewModel() {

    private val _state = MutableStateFlow(RoomsUiState())
    val state: StateFlow<RoomsUiState> = _state.asStateFlow()

    /**
     * Called from the host (Dashboard / Attendance) when navigating into this screen
     * so the ViewModel can be pre-loaded with the correct room context.
     */
    fun loadRoom(roomNumber: String, block: String, course: String) {
        _state.update { current ->
            current.copy(
                roomInfo = RoomInfo(
                    roomNumber = roomNumber,
                    block = block,
                    course = course,
                ),
            )
        }
    }

    /** Toggle the state of a seat (Assigned ↔ Empty for now). */
    fun onSeatClick(seat: SeatData) {
        _state.update { current ->
            val updated = current.seats.map { s ->
                if (s.row == seat.row && s.col == seat.col) {
                    s.copy(
                        state = when (s.state) {
                            SeatState.Assigned -> SeatState.Empty
                            SeatState.Empty    -> SeatState.Assigned
                            SeatState.Absent   -> SeatState.Assigned
                            SeatState.Verified -> SeatState.Assigned
                        },
                    )
                } else s
            }
            current.copy(seats = updated)
        }
    }
}
