package com.invex.app.schedule

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/** One block on the day timeline. Hours are 24h clock whole hours: 11 to 12 is "11:00 AM to 12:00 PM". */
data class ScheduleEvent(
    val id: String,
    val title: String,
    val startHour: Int,
    val endHour: Int,
)

data class ScheduleUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    /** First day (Monday) of the week shown in the date strip. */
    val weekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)),
    /** Timeline runs from [firstHour] to [lastHour], one row per hour. */
    val firstHour: Int = 9,
    val lastHour: Int = 16,
    /** Sample data. TODO: load per selected date from the backend; for now every day shows the same events. */
    val events: List<ScheduleEvent> = listOf(
        ScheduleEvent("1", "Examination Hall B", 11, 12),
        ScheduleEvent("2", "Examination Hall B", 14, 15),
    ),
) {
    val weekDays: List<LocalDate> get() = (0..6).map { weekStart.plusDays(it.toLong()) }
    val hours: List<Int> get() = (firstHour..lastHour).toList()
}
