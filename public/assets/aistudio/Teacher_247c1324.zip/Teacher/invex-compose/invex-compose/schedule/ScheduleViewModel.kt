package com.invex.app.schedule

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.time.LocalDate

class ScheduleViewModel : ViewModel() {

    private val _state = MutableStateFlow(ScheduleUiState())
    val state: StateFlow<ScheduleUiState> = _state.asStateFlow()

    fun onDateSelected(date: LocalDate) = _state.update { it.copy(selectedDate = date) }

    /** The chevrons move the strip by a week and keep the same weekday selected. */
    fun onPreviousWeek() = shiftWeek(-7)

    fun onNextWeek() = shiftWeek(7)

    private fun shiftWeek(days: Long) = _state.update {
        it.copy(weekStart = it.weekStart.plusDays(days), selectedDate = it.selectedDate.plusDays(days))
    }
}
