package com.invex.app.login

/**
 * Who is logging in. The selector under the logo switches this. The label above the first field follows it.
 * Only "Faculty" is drawn; "Student" is assumed from the dropdown arrow and the Student page in Figma.
 */
enum class UserRole(val label: String, val idLabel: String) {
    FACULTY("Faculty", "Faculty ID"),
    STUDENT("Student", "Student ID"),
}

data class LoginUiState(
    val role: UserRole = UserRole.FACULTY,
    val userId: String = "",
    val password: String = "",
)
