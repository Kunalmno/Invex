package com.invex.app.login

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class LoginViewModel : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    fun onRoleChange(role: UserRole) = _state.update { it.copy(role = role) }

    fun onUserIdChange(value: String) = _state.update { it.copy(userId = value) }

    fun onPasswordChange(value: String) = _state.update { it.copy(password = value) }

    // TODO: validate the fields and call the backend here. The design has no error or loading state yet,
    // so for now the Login button simply continues.
}
