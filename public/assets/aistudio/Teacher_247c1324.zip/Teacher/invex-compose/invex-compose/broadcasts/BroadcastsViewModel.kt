package com.invex.app.broadcasts

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class BroadcastsViewModel : ViewModel() {

    private val _state = MutableStateFlow(BroadcastsUiState())
    val state: StateFlow<BroadcastsUiState> = _state.asStateFlow()

    /** Tap on the "Broadcasts" heading on the Dashboard. */
    fun openList() = _state.update { it.copy(sheet = BroadcastSheet.List) }

    /** Tap on a broadcast row, on the Dashboard or inside the list. Opens that broadcast's own page. */
    fun openDetail(id: String) = _state.update { it.copy(sheet = BroadcastSheet.Detail(id)) }

    /** Swipe down or tap outside. Always goes back to the Dashboard. */
    fun dismiss() = _state.update { it.copy(sheet = BroadcastSheet.Closed) }
}
