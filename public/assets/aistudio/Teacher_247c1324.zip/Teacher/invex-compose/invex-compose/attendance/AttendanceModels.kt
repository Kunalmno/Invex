package com.invex.app.attendance

import androidx.compose.ui.graphics.Color

data class AttendanceSummary(
    val total: Int = 0,
    val present: Int = 0,
    val absent: Int = 0,
)

data class AttendanceStudent(
    val id: String,
    val name: String,
    val course: String,
    val year: String,
    val rollNumber: String,
    val count: Int,
    val statusLabel: String,
) {
    val meta: String get() = "$course | $year | $rollNumber"
}

/** One arc of the donut chart. Arcs are drawn clockwise from 12 o'clock, in list order. */
data class DonutSlice(val value: Float, val color: Color)
