package com.invex.app.attendance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.invex.app.R
import com.invex.app.ui.components.InvexSearchBar
import com.invex.app.ui.components.ScreenHeader
import com.invex.app.ui.components.StudentRow
import com.invex.app.ui.components.sectionGap
import com.invex.app.ui.theme.InvexTheme
import com.invex.app.ui.theme.InvexType
import com.invex.app.ui.theme.MobileBackground
import com.invex.app.ui.theme.SectionHeadingColor

/** Stateful entry point: owns the ViewModel. */
@Composable
fun AttendanceRoute(
    onBack: () -> Unit,
    viewModel: AttendanceViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsState()
    AttendanceScreen(
        state = state,
        onBack = onBack,
        onCourseSelected = viewModel::onCourseSelected,
        onQueryChange = viewModel::onQueryChange,
    )
}

/** Stateless screen: easy to preview and test. */
@Composable
fun AttendanceScreen(
    state: AttendanceUiState,
    onBack: () -> Unit,
    onCourseSelected: (String) -> Unit,
    onQueryChange: (String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MobileBackground)
            .statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        // 12dp between items; sectionGap() makes it 24dp between sections.
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ScreenHeader(
                title = "Attendance",
                glyphRes = R.drawable.ic_attendance,
                glyphPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                onBack = onBack,
            )
        }
        sectionGap()
        item {
            CourseSelector(
                selected = state.selectedCourse,
                courses = state.courses,
                onSelect = onCourseSelected,
            )
        }
        item { AttendanceStatusRow(state.summary) }
        sectionGap()
        item { Text("Analytics", style = InvexType.SectionHeadingBold, color = SectionHeadingColor) }
        item { AnalyticsCard(slices = state.chart, summary = state.summary) }
        sectionGap()
        item { Text("Students", style = InvexType.SectionHeading, color = SectionHeadingColor) }
        item { InvexSearchBar(query = state.query, onQueryChange = onQueryChange) }
        itemsIndexed(state.visibleStudents, key = { _, s -> s.id }) { index, student ->
            StudentRow(
                name = student.name,
                meta = student.meta,
                count = student.count,
                tag = student.statusLabel,
                // 12dp item spacing + 4dp = the 16dp gap between the search bar and the first row.
                modifier = if (index == 0) Modifier.padding(top = 4.dp) else Modifier,
            )
        }
    }
}

@Preview(showBackground = true, widthDp = 390, heightDp = 1086)
@Composable
private fun AttendanceScreenPreview() {
    InvexTheme {
        AttendanceScreen(
            state = AttendanceViewModel().state.value,
            onBack = {},
            onCourseSelected = {},
            onQueryChange = {},
        )
    }
}
