package com.invex.app.attendance

import androidx.lifecycle.ViewModel
import com.invex.app.ui.theme.LightBrown
import com.invex.app.ui.theme.Mist
import com.invex.app.ui.theme.PaleBrown
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

const val ALL_COURSES = "All Courses"

data class AttendanceUiState(
    val courses: List<String> = listOf(ALL_COURSES),
    val selectedCourse: String = ALL_COURSES,
    val summary: AttendanceSummary = AttendanceSummary(),
    val chart: List<DonutSlice> = emptyList(),
    val query: String = "",
    val allStudents: List<AttendanceStudent> = emptyList(),
) {
    val visibleStudents: List<AttendanceStudent>
        get() = if (query.isBlank()) allStudents else allStudents.filter {
            it.name.contains(query, ignoreCase = true) ||
                it.rollNumber.contains(query, ignoreCase = true) ||
                it.course.contains(query, ignoreCase = true)
        }
}

class AttendanceViewModel : ViewModel() {

    // Sample data copied from the Figma frame. Swap for a repository later.
    private val _state = MutableStateFlow(
        AttendanceUiState(
            courses = listOf(ALL_COURSES, "B.Tech CSE", "B.Tech ECE", "M.Tech"),
            summary = AttendanceSummary(total = 1, present = 15, absent = 1),
            // Placeholder values from the design (20 / 20 / 42). Decide what each slice means.
            chart = listOf(
                DonutSlice(20f, LightBrown),
                DonutSlice(20f, PaleBrown),
                DonutSlice(42f, Mist),
            ),
            allStudents = List(3) { i ->
                AttendanceStudent(
                    id = "s$i",
                    name = "Lorem Ipsum Dorem",
                    course = "B.tech",
                    year = "3rd Year",
                    rollNumber = "7045",
                    count = 1,
                    statusLabel = "Resolved",
                )
            },
        )
    )
    val state: StateFlow<AttendanceUiState> = _state.asStateFlow()

    fun onQueryChange(query: String) = _state.update { it.copy(query = query) }

    // TODO: reload summary, chart and students for the chosen course.
    fun onCourseSelected(course: String) = _state.update { it.copy(selectedCourse = course) }
}
