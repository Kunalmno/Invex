package com.invex.app.register

import androidx.lifecycle.ViewModel
import com.invex.app.login.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class RegisterViewModel : ViewModel() {

    private val _state = MutableStateFlow(RegisterUiState())
    val state: StateFlow<RegisterUiState> = _state.asStateFlow()

    fun onRoleChange(role: UserRole) = _state.update { it.copy(role = role) }

    fun onUserIdChange(value: String) = _state.update { it.copy(userId = value, errorMessage = null) }

    fun onCreatePasswordChange(value: String) = _state.update { it.copy(createPassword = value, errorMessage = null) }

    fun onConfirmPasswordChange(value: String) = _state.update { it.copy(confirmPassword = value, errorMessage = null) }

    /**
     * Validates input fields and returns true if registration can proceed.
     */
    fun validate(): Boolean {
        val current = _state.value
        if (current.userId.isBlank()) {
            _state.update { it.copy(errorMessage = "Please enter your ${current.role.idLabel}") }
            return false
        }
        if (current.createPassword.isBlank()) {
            _state.update { it.copy(errorMessage = "Please enter a password") }
            return false
        }
        if (current.createPassword.length < 6) {
            _state.update { it.copy(errorMessage = "Password must be at least 6 characters") }
            return false
        }
        if (current.createPassword != current.confirmPassword) {
            _state.update { it.copy(errorMessage = "Passwords do not match") }
            return false
        }
        return true
    }
}
