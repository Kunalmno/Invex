package com.invex.app.circulars

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CircularsViewModel : ViewModel() {

    private val _state = MutableStateFlow(CircularsUiState())
    val state: StateFlow<CircularsUiState> = _state.asStateFlow()

    /** Tap on the "Circulars" heading on the Dashboard. */
    fun openList() = _state.update { it.copy(sheet = CircularSheet.List) }

    /** Tap on a circular row, on the Dashboard or inside the list. Opens that circular's own page. */
    fun openDetail(id: String) = _state.update { it.copy(sheet = CircularSheet.Detail(id)) }

    /** Swipe down or tap outside. Always goes back to the Dashboard. */
    fun dismiss() = _state.update { it.copy(sheet = CircularSheet.Closed) }
}
