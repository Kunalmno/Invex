package com.invex.app.verifyadmit

enum class VerifyTab(val label: String) {
    ScanQr("Scan QR"),
    Students("Students"),
}

data class VerifyAdmitUiState(
    val tab: VerifyTab = VerifyTab.ScanQr,
    /** True while the camera is looking for a QR code. Starts on, stops after the first code is read. */
    val scanning: Boolean = true,
    /** Raw text of the last QR code read, or null. Sent to the backend for verification (not built yet). */
    val lastScan: String? = null,
)
