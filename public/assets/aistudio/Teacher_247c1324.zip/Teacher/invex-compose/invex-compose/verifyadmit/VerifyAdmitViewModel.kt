package com.invex.app.verifyadmit

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class VerifyAdmitViewModel : ViewModel() {

    private val _state = MutableStateFlow(VerifyAdmitUiState())
    val state: StateFlow<VerifyAdmitUiState> = _state.asStateFlow()

    fun onTabSelected(tab: VerifyTab) = _state.update { it.copy(tab = tab) }

    /** Camera found a QR code: stop scanning so one code is not handled many times. */
    fun onQrScanned(value: String) {
        if (!_state.value.scanning) return
        _state.update { it.copy(scanning = false, lastScan = value) }
        // TODO: verify the admit card with the backend using [value].
    }

    /** "Scan the Student" button: look for the next code. */
    fun onScanStudent() = _state.update { it.copy(tab = VerifyTab.ScanQr, scanning = true, lastScan = null) }
}
