# Room View (Teacher Page)

Design spec for the **Room View** frame of the InvEx mobile application.

- **Sources:**
  - Layout & XML exports: `roomViewScreen.xml` (frame 390 x 844 dp)
  - Screenshot reference: Attached room view design (`media_1794237798869_644a0551.png`)
  - Icon assets: `c:\Users\abc\Saved Games\Notes\Invex\rooms\` → `ic_room_heading.svg` (50 x 50 dp Orange sofa badge), `ic_seat_room.svg` (30 x 30 dp sofa glyph)
- **Purpose:** Teacher-facing screen showing the full seating layout of an assigned examination room, broken into named seat cells (row-column format: A1–G6), grouped by course with a colour-coded legend row at the bottom. The teacher can at-a-glance confirm occupied vs. absent seats and understand which students belong to which course.

---

## 1. Frame

| Property | Value |
|---|---|
| Reference Size | 390 x 844 dp (standard mobile viewport; content may scroll if rows overflow) |
| Background | `MobileBackground` `#EBEBEB` |
| Border | 2px `OutlineShadow` `#E8E8E8` |
| Corner Radius | 15dp (frame) |
| Layout | Vertical scrollable column (`LazyColumn` or `verticalScroll`) |
| Padding | 20dp top, 16dp horizontal, 24dp bottom |
| Section Gap | 12dp – 16dp vertical gap between major blocks |

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#EBEBEB` | Screen background |
| `OutlineShadow` | `#E8E8E8` | Frame border, seat grid card border |
| `TableRowInteraction` | `#FAFAFA` | Seat grid card background (the rounded white card containing the seat table) |
| `Orange` | `#ED451F` | Header icon circle fill, page title underline bar |
| `IconColor` | `#171717` | Page title text colour |
| `TableHeaderText` | `#737373` | Subtitle text ("Room : 317 | Block : B | Course : OOPS") |
| `SoftWhite` | `#F7F9F7` | Sofa glyph fill on Orange header badge |
| `HoverSelect` | `#F5F5F5` | Individual seat tile background (light pink-tinted grey per mockup) |

### Non-Tokenised / Hard-coded Values

| Value | Used for |
|---|---|
| `#FDDDD8` / `#F9E0DC` | Seat tile background tint (pinkish fill visible in screenshot — slightly warmer than `HoverSelect`) |
| `#000000` | Seat label text (e.g., "A1", "B3") |
| `#000000` | Sofa seat glyph fill inside each seat tile |
| `#FAFAFA` | Course legend card background |
| `#1A6B3A` / `#2D7A4F` | Sofa icon fill colour inside course legend cards (dark green, as visible in mockup) |

> [!NOTE]
> The seat tile pink fill (`#FDDDD8`) is not a named Figma variable; it appears to be a hard-coded fill on the seat tile shape. If a future token is added for seat tiles, name it `SeatTileBackground`.

---

## 3. Typography

| Use | Font Family | Weight | Size / Line Height | Colour |
|---|---|---|---|---|
| **Page Heading** ("Room") | Pixelify Sans | SemiBold | 36sp / 40sp | `#171717` with 3dp `Orange` underline bar |
| **Subtitle / Meta Line** ("Room : 317 \| Block : B \| Course : OOPS") | Inter | Regular | 13sp / 18sp | `#737373` |
| **Seat Label** ("A1", "B3", …) | Inter | Medium | 10sp / 12sp | `#000000` |
| **Course Legend Label** ("Course 1", "Course 2", …) | Inter | SemiBold | 16sp / 20sp | `#000000` |

---

## 4. Layout Structure

```
RoomView (390 x 844 dp)
├── Header Block                                (fillMaxWidth, height ~44dp)
│   ├── Back Chevron: ic_chevron_back            (30 x 30 dp, tapable)
│   ├── Room Icon Badge: Orange circle + sofa   (50 x 50 dp, ic_room_heading.svg)
│   └── Page Heading: "Room"                    (Pixelify Sans 36sp + 3dp orange underline)
├── Subtitle Line                               (fillMaxWidth, height ~20dp)
│   └── "Room : 317 | Block : B | Course : OOPS"  (Inter Regular 13sp, #737373)
├── Seat Grid Card                              (fillMaxWidth, corner 16dp, #FAFAFA fill, 1dp #E8E8E8 border)
│   └── 7-Row × 6-Column Grid of SeatTiles     (rows A–G, columns 1–6)
│       └── SeatTile (each)                    (~52 x 60 dp, #FDDDD8 fill, corner 10dp)
│           ├── Sofa Icon: ic_seat_room.svg     (30 x 30 dp, black fill)
│           └── Seat Label: "A1" … "G6"        (Inter Medium 10sp, below icon)
└── Course Legend Row                           (fillMaxWidth, 2-column × 2-row grid, 12dp gap)
    ├── Course 1 Card  (sofa icon [green] + "Course 1")
    ├── Course 2 Card  (sofa icon [green] + "Course 2")
    ├── Course 3 Card  (sofa icon [green] + "Course 3")
    └── Course 4 Card  (sofa icon [green] + "Course 4")
```

---

## 5. Component Breakdown

### 5.1 Header Block

Same pattern as `ScreenHeader` in `InvexComponents.kt`:

- **Back Chevron:** 30 x 30 dp, `ic_chevron_back`, tapable area, navigates back to Dashboard / Attendance.
- **Room Icon Badge:** 50 x 50 dp circle, `Orange` (`#ED451F`) fill, containing `ic_room_heading.svg` (sofa on orange background — the icon itself is the entire orange circle, so the badge IS the icon, no additional circle wrapping needed).
- **Page Heading:** `"Room"` in Pixelify Sans SemiBold 36sp, `#171717`, with a 3dp `Orange` underline bar drawn via `LineUnderlinedText`.

### 5.2 Subtitle Meta Line

Single horizontal text line directly below the header:

```
Room : 317  |  Block : B  |  Course : OOPS
```

- Font: Inter Regular 13sp, `#737373`.
- Separators `|` are part of the text string (or rendered as `Text` with `•` / pipe characters).
- Values are dynamic — populated from the selected room/course context.

| Field | Sample Value | Source |
|---|---|---|
| Room | 317 | Active duty assignment |
| Block | B | Building block |
| Course | OOPS | Examination course code |

### 5.3 Seat Grid Card

Large rounded container holding the full seating layout:

- **Card:** `fillMaxWidth`, `TableRowInteraction` (`#FAFAFA`) fill, 1dp `OutlineShadow` border, 16dp corner radius, 12dp internal padding.
- **Grid Layout:** 7 rows (A through G) × 6 columns (1 through 6) = 42 seats total.
  - Row labels: A, B, C, D, E, G (note: row **F is skipped** in the mockup — may indicate absentees row or a data gap; treat as configurable).
  - Column labels: 1 through 6.
- **Seat Name Convention:** Row letter + Column number, e.g., `A1`, `B3`, `G6`.
- **Grid spacing:** 8dp horizontal gap, 10dp vertical gap between seat tiles.

#### SeatTile

Each individual seat cell:

| Property | Value |
|---|---|
| Width | ~52dp (auto-sized from grid weight, 6 columns with 8dp gaps across fillMaxWidth) |
| Height | ~60dp |
| Background | `#FDDDD8` (pinkish warm tint) |
| Corner Radius | 10dp |
| Border | None (no explicit border stroke visible in mockup) |
| Icon | `ic_seat_room.svg` — 30 x 30 dp sofa glyph, `#000000` fill |
| Label | Seat name (e.g., `"A1"`) — Inter Medium 10sp, `#000000`, centered below icon |
| Padding | 6dp top, 4dp bottom, 4dp horizontal |

> [!TIP]
> Use `LazyVerticalGrid(columns = GridCells.Fixed(6))` with `itemsIndexed` or a row-by-row `LazyColumn` of `Row` composables for the seat layout. The fixed 6-column approach maps directly to the Figma grid.

### 5.4 Course Legend Row

Bottom section displaying which courses are present in this room, acting as a visual key for future seat colouring:

- **Layout:** 2 × 2 grid (2 cards per row, 2 rows = 4 cards total). 12dp gap between cards.
- **Card dimensions:** Each card fills ~(screenWidth - 32dp padding - 12dp gap) / 2 ≈ 173dp wide, ~52dp tall.

#### CourseLegendCard

| Property | Value |
|---|---|
| Background | `#FAFAFA` (`TableRowInteraction`) |
| Corner Radius | 12dp |
| Border | 1dp `OutlineShadow` (`#E8E8E8`) |
| Icon | `ic_seat_room.svg` — 24 x 24 dp, **dark green fill** (`#1A6B3A` or `#2D7A4F`) |
| Label | Course name (e.g., `"Course 1"`) — Inter SemiBold 16sp, `#000000` |
| Icon-label gap | 12dp horizontal |
| Padding | 12dp horizontal, 14dp vertical |
| Alignment | Icon + Label centred vertically, left-aligned within card |

> [!NOTE]
> The sofa icon inside the legend cards is tinted **dark green** (not black), distinguishing it from the seat grid where it is plain black. Use `ColorFilter.tint(Color(0xFF1A6B3A))` on the `Image` composable.

---

## 6. Assets & Icons Mapping

| Asset File | Dimensions | Used For | Visual Description |
|---|---|---|---|
| `ic_room_heading.svg` | 50 x 50 dp | Header icon badge | Orange circle (rx=25) with white sofa/couch glyph centered inside |
| `ic_seat_room.svg` | 30 x 30 dp | Each seat tile + legend cards | Line-art sofa/couch in black (or dark green for legend) |
| `ic_chevron_back.svg` | 30 x 30 dp | Header back navigation | Left-pointing chevron arrow (from `Teacher/icons/`) |

> [!IMPORTANT]
> `ic_room_heading.svg` already includes the orange circular background as part of the vector. Do **not** wrap it in an additional `Box` with `Orange` background — just render the SVG/XML at 50 x 50 dp directly. This differs from other screens where the orange circle is a separate `Box` wrapping a plain glyph icon.

---

## 7. Behavior & Interaction Notes

1. **Back Navigation:** Tapping the chevron navigates back to the Dashboard or Attendance screen (wherever the teacher opened Room View from).
2. **Seat Selection (future):** Tapping a seat tile could open a student detail sheet (name, reg no, seat assignment confirmation). Currently the mockup shows all seats in the same pink state; a selected/active state could use `Orange` fill.
3. **Course Legend:** Each legend card represents a course running in this room (multiple courses can share a hall during exams). The card count matches the number of distinct courses assigned to the room.
4. **Dynamic Room Data:** All values (`Room : 317`, `Block : B`, `Course : OOPS`) come from the teacher's active duty assignment and should be passed as navigation arguments or ViewModel state.
5. **Absent / Empty Seats:** Future variants could differentiate seat states:
   - **Pink** (`#FDDDD8`) — Assigned / present (default)
   - **Grey** (`#E8E8E8`) — Empty / unassigned
   - **Red** (`StatusRed`) — Absent
   - **Green** (`StatusGreen`) — Verified present

---

## 8. Build Notes (Jetpack Compose Implementation)

### Package
```
com.invex.app.rooms
```

### Suggested File Structure
```
rooms/
├── RoomsModels.kt        — data classes: RoomInfo, SeatData, CourseItem, RoomsUiState
├── RoomsViewModel.kt     — holds room + seat grid state, exposes uiState: StateFlow
├── RoomsComponents.kt    — SeatTile, SeatGrid, CourseLegendCard, CourseLegendGrid
└── RoomsScreen.kt        — RoomsRoute (stateful) + RoomsScreen (stateless) + @Preview
```

### Key Compose Patterns

```kotlin
// Seat grid — fixed 6 columns
LazyVerticalGrid(
    columns = GridCells.Fixed(6),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    modifier = Modifier.padding(12.dp),
) {
    items(seats) { seat ->
        SeatTile(seat = seat)
    }
}
```

```kotlin
// SeatTile composable
@Composable
fun SeatTile(seat: SeatData, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFFFDDDD8))
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Image(
            painter = painterResource(R.drawable.ic_seat_room),
            contentDescription = seat.label,
            modifier = Modifier.size(30.dp),
        )
        Text(
            text = seat.label,         // e.g. "A1"
            style = InvexType.RowMeta, // Inter Medium 10sp
            color = Color.Black,
        )
    }
}
```

```kotlin
// ic_room_heading: render as-is (orange circle is baked into the SVG)
Image(
    painter = painterResource(R.drawable.ic_room_heading),
    contentDescription = null,
    modifier = Modifier.size(50.dp),
)

// ic_seat_room with green tint for legend cards
Image(
    painter = painterResource(R.drawable.ic_seat_room),
    contentDescription = null,
    colorFilter = ColorFilter.tint(Color(0xFF1A6B3A)),
    modifier = Modifier.size(24.dp),
)
```

### Navigation
- Add `const val RoomView = "room_view/{roomId}"` to `Route` in `InvexApp.kt`.
- Navigate from Dashboard / Attendance passing the room ID or room details as arguments.

---

## 9. Open Questions

- **Row F missing:** The mockup shows rows A, B, C, D, E, G (F is absent). Is this intentional (F row physically doesn't exist in this room layout), or a data gap? Confirm with the designer whether the row set is data-driven or hard-coded per room.
- **Seat State Colouring:** All seats are the same pink in the current mockup. Will seat states (absent, verified, flagged) be colour-coded in the final design?
- **Course Count:** 4 course legend cards are shown. Is this fixed or dynamically driven by the number of courses assigned to the room?
- **Seat Tap Action:** Does tapping a seat open a detail panel, or is the grid display-only for now?
