# RestroomPass (Teacher Page)

Design spec for the **Restroom Pass** frame of the InvEx mobile application.

- **Sources:** 
  - Layout & XML exports: `RestroomPass.xml` (frame 390x920 dp), `TicketCard.xml` (ticket card 358x325.38 dp)
  - Screenshot reference: Attached restroom pass design (`media_1794212328699_8adb31db.png`)
  - Icon assets: `c:\Users\abc\Saved Games\Notes\Invex\restroomPassIcon\` (mirrored in `Teacher/icons/`)
- **Purpose:** Teacher-facing mobile screen for managing and tracking student restroom passes during active examination sessions: summary status counts (Out, Returned, Overdue), pass issuance action, a detailed active pass ticket card (with live countdown, student credentials, runner timeline, and QR verification), and a history log of recent passes.

---

## 1. Frame

| Property | Value |
|---|---|
| Reference Size | 390 x 920 dp (taller than standard screen; content scrolls vertically) |
| Background | `MobileBackground` `#EBEBEB` |
| Border | 2px `OutlineShadow` `#E8E8E8` |
| Corner Radius | 15dp |
| Layout | Vertical scrollable column (`LazyColumn` or `verticalScroll`) |
| Padding | 48dp top, 16dp horizontal, 24dp bottom |
| Section Gap | 20dp – 24dp vertical gap between major blocks |

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#EBEBEB` | Screen background |
| `OutlineShadow` | `#E8E8E8` | Frame borders, status card borders, divider lines |
| `HoverSelect` | `#F5F5F5` | Summary status cards fill (Out / Returned / Overdue) |
| `TableRowInteraction` | `#FAFAFA` | Active ticket card fill, recent pass cards fill |
| `Orange` | `#ED451F` | Header circle icon fill, title underline bar, "Issue Pass" button |
| `IconColor` | `#171717` / `#000000` | Header title, active badge fill, runner glyph |
| `TableHeaderText` | `#737373` | Subtitles, field labels ("Student", "Seat", "Reg No", "Course"), timestamps |
| `SoftWhite` | `#FFFFFF` / `#F7F9F7` | Text on the orange button, active badge text, ticket background highlights |
| `StatusGreen` | `#66CD4C` | "Out" status dot (1px black border, 4dp radius) |
| `StatusYellow` | `#FFDE7C` | "Returned" status dot (1px black border, 4dp radius) |
| `StatusRed` | `#F24E51` | "Overdue" status dot (1px black border, 4dp radius) |

### Non-Tokenized / Hard-coded Values:

| Value | Used for |
|---|---|
| `#B2AFAF` | Ticket card outer border stroke (2px) |
| `#F7EFEB` | "Time Remaining" banner background inside active ticket |
| `#BDB6B3` / `#CCCCCC` | "Report" pill button background |
| `#0D0D0D` | Status card labels ("Out", "Returned", "Overdue") |
| `#040404` / `#000000` | Section headings ("Active Pass", "Recent Pass") |

---

## 3. Typography

| Use | Font Family | Weight | Size / Line Height | Color & Style |
|---|---|---|---|---|
| **Page Heading** ("Restroom Pass") | Pixelify Sans | SemiBold | 36sp / 40sp | `#000000` with 3dp `Orange` underline bar |
| **Status Card Label** ("Out", "Returned", "Overdue") | Inter | SemiBold | 14sp / 14sp | `#0D0D0D` |
| **Status Card Count** ("01", "15", "01") | Inter | SemiBold | 24sp / 24sp | `#000000` |
| **Issue Button Label** ("Issue a Supplementary Sheet" / "Issue Pass") | Inter | SemiBold | 18sp / 32sp | `SoftWhite` (`#FFFFFF`) |
| **Section Headings** ("Active Pass", "Recent Pass") | Inter | SemiBold / Bold | 26sp / 32sp | `#000000` |
| **Timeline Labels** ("Left Hall At", "Elapsed at") | Inter | Regular | 11sp / 14sp | `#737373` |
| **Timeline Times** ("09:00", "09:15") | Inter | Bold | 20sp / 24sp | `#000000` |
| **Runner Duration** ("15 Minutes") | Inter | Medium | 10sp / 12sp | `#000000` |
| **Active Status Badge** ("Active") | Inter | Medium | 10sp / 10sp | `#FFFFFF` |
| **Remaining Label** ("Time Remaining") | Inter | Medium | 10sp / 12sp | `#737373` |
| **Remaining Countdown** ("15 minutes 00 second") | Inter | SemiBold | 15sp / 18sp | `#000000` |
| **Report Button Text** ("Report") | Inter | Medium | 10sp / 12sp | `#333333` |
| **Student Metadata Headers** ("Student", "Seat", "Reg No", "Course") | Inter | Medium | 11sp / 14sp | `#737373` |
| **Student Metadata Values** ("John Doe", "A2", "7890", "B. tech") | Inter | SemiBold | 14sp / 18sp | `#000000` |
| **Ticket Action Labels** ("Info", "Download") | Inter | Medium | 9sp / 12sp | `#000000` |
| **Ticket Validity Date** ("Valid Until 01 Jan 27 09:15:00") | Inter | Regular | 8sp / 10sp | `#737373` |
| **QR Serial Number** ("No . 1234567890") | Inter | Regular | 8sp / 10sp | `#000000` |
| **Recent Pass Student Name** ("Lorem Ipsum") | Inter | SemiBold | 16sp / 20sp | `#000000` |
| **Recent Pass Status** ("Returned") | Inter | Medium | 12sp / 14sp | `#737373` |
| **Recent Pass Validity** ("Valid Until 01 Jan 26") | Inter | Regular | 9sp / 12sp | `#737373` |
| **Recent Pass Duration** ("5 min") | Inter | SemiBold | 16sp / 20sp | `#000000` |
| **Recent Pass Time Range** ("09:00 AM - 09:15 AM") | Inter | Regular | 9sp / 12sp | `#737373` |

---

## 4. Layout Structure

```
RestroomPass (390 x 920 dp)
├── Header Block (358 x 40 dp)
│   ├── Back Chevron: ic_chevron_back                  (30 x 30 dp)
│   ├── Pass Icon Badge: Orange circle + ticket glyph (40 x 40 dp)
│   └── Page Heading: "Restroom Pass"                  (Pixelify Sans 36sp + orange underline bar)
├── Summary Status Cards Row (358 x 70 dp, 12dp gap)
│   ├── Card 1 (Out):      Green dot + "Out" + "01"    (110 x 70 dp, #F5F5F5, radius 10dp)
│   ├── Card 2 (Returned): Yellow dot + "Returned" + "15" (110 x 70 dp, #F5F5F5, radius 10dp)
│   └── Card 3 (Overdue):  Red dot + "Overdue" + "01"  (110 x 70 dp, #F5F5F5, radius 10dp)
├── Issue Pass Action Button (358 x 60 dp, #ED451F, radius 15dp)
│   ├── Leading Icon: White circle with plus glyph     (50 x 50 dp)
│   └── Button Label: "Issue a Supplementary Sheet"    (Inter SemiBold 18sp, white)
├── Active Pass Section (358 dp wide)
│   ├── Section Heading: "Active Pass"                 (Inter SemiBold 26sp, black)
│   └── Ticket Card (358 x 325.38 dp, #FAFAFA, border 2px #B2AFAF, radius 10dp)
│       ├── Timeline Row
│       │   ├── Left: "Left Hall At" + "09:00"
│       │   ├── Dotted Line Track
│       │   ├── Center Node: ic_running.svg + "15 Minutes" + "Active" black pill badge
│       │   ├── Dotted Line Track
│       │   └── Right: "Elapsed at" + "09:15"
│       ├── Time Remaining Card (330 x 46 dp, fill #F7EFEB, radius 10dp)
│       │   ├── Left: "Time Remaining" + "15 minutes 00 second"
│       │   └── Right: "Report" action pill button     (#BDB6B3 fill)
│       ├── Student Metadata Row (4-column grid)
│       │   ├── Student: "John Doe"
│       │   ├── Seat: "A2"
│       │   ├── Reg No: "7890"
│       │   └── Course: "B. tech"
│       ├── Ticket Perforation Divider
│       │   ├── Left Semicircular Cutout Notch        (radius ~12dp)
│       │   ├── Dotted Perforation Line               (dashed 1dp)
│       │   └── Right Semicircular Cutout Notch       (radius ~12dp)
│       └── Bottom Verification Bar
│           ├── Info Column: ic_info.svg (16dp) + "Info" + "Valid Until 01 Jan 27 09:15:00"
│           ├── QR Column: ic_qrcode.svg (35x34dp) + "No . 1234567890"
│           └── Download Column: ic_download.svg (16dp) + "Download"
└── Recent Pass Section (358 dp wide)
    ├── Section Heading: "Recent Pass"                 (Inter SemiBold 26sp, black)
    └── Recent Pass List (vertical stack, 12dp gap)
        ├── Card 1 (Returned Pass, 358 x 80 dp, radius 15dp, #FAFAFA)
        │   ├── Left: ic_returned.svg                  (50 x 50 dp black check circle)
        │   ├── Middle: "Lorem Ipsum" + "Returned" + "Valid Until 01 Jan 26"
        │   └── Right: "5 min" + "09:00 AM - 09:15 AM"
        └── Card 2 (Alert/Overdue Pass, 358 x 80 dp, radius 15dp, #FAFAFA)
            ├── Left: ic_notreturned.svg              (50 x 50 dp warning triangle)
            ├── Middle: "Lorem Ipsum" + "Returned" + "Valid Until 01 Jan 26"
            └── Right: "5 min" + "09:00 AM - 09:15 AM"
```

---

## 5. Component Breakdown

### 5.1 Header Block
- **Chevron Back:** 30x30 dp tap target to return to the active examination hall or dashboard.
- **Pass Icon Badge:** 40x40 dp circle (radius 25dp), filled with `Orange` (`#ED451F`), containing a white pass/ticket icon with side notches.
- **Title:** `"Restroom Pass"` in Pixelify Sans SemiBold 36sp, `#000000`, with a 3dp orange underline bar (offset 4dp) using `LineUnderlinedText`.

### 5.2 Summary Status Cards (PassesStatusCard)
Three cards arranged horizontally with 12dp gap inside a 358dp row:
- Each card: 110 x 70 dp, `HoverSelect` (`#F5F5F5`) fill, 1px `OutlineShadow` (`#E8E8E8`) border, 10dp radius.
- Status indicator dot: 10x10 dp at (16dp, 10dp), 1px solid black border, 4dp radius.
- Label: Inter SemiBold 14sp, color `#0D0D0D`.
- Count: Inter SemiBold 24sp, color `#000000`.

| Card | Label | Dot Color | Sample Count | Definition |
|---|---|---|---|---|
| Card 1 | **Out** | Green `#66CD4C` | 01 | Students currently outside the hall on pass |
| Card 2 | **Returned** | Yellow `#FFDE7C` | 15 | Passes completed and returned today |
| Card 3 | **Overdue** | Red `#F24E51` | 01 | Passes that have exceeded the 15-minute window |

### 5.3 Issue Pass Action Button
- **Dimensions:** 358 x 60 dp, 15dp corner radius, background `Orange` (`#ED451F`).
- **Leading Icon:** 50x50 dp white circular glyph with an orange plus sign (`ic_circle_plus.svg`).
- **Text:** `"Issue a Supplementary Sheet"` in Inter SemiBold 18sp, `SoftWhite` (`#FFFFFF`).
  > [!NOTE]
  > The Figma design reuses the button component from the Supplement Sheet screen ("Issue a Supplementary Sheet"). In code, provide a default parameter for this label allowing either the mockup string or `"Issue a Restroom Pass"`.

### 5.4 Active Pass Ticket Card
Detailed 358 x 325.38 dp card representing an in-flight pass:
- **Card Styling:** `TableRowInteraction` (`#FAFAFA`) fill, 2px border `#B2AFAF`, 10dp corner radius.
- **Top Runner Timeline:**
  - Left: `"Left Hall At"` above departure time `"09:00"`.
  - Center: Running student glyph (`ic_running.svg`, 26x26dp) above `"15 Minutes"`, anchored over a black pill badge (`#151515`, corner radius 10dp) displaying `"Active"` in white 10sp text.
  - Right: `"Elapsed at"` above expected return time `"09:15"`.
  - Dotted track: 2dp dashed line running behind the central runner glyph.
- **Time Remaining Banner:**
  - Soft beige rounded card (`#F7EFEB`), 10dp corner radius, 1px `#E8E8E8` border.
  - Left: `"Time Remaining"` (Inter Medium 10sp, `#737373`) over countdown clock `"15 minutes 00 second"` (Inter SemiBold 15sp, `#000000`).
  - Right: `"Report"` button in `#BDB6B3` / `#CCCCCC` pill (Inter Medium 10sp) for reporting students who take too long or violate exam conduct.
- **Student Information Grid:**
  - 4 columns evenly spaced:
    - `Student`: `"John Doe"`
    - `Seat`: `"A2"`
    - `Reg No`: `"7890"`
    - `Course`: `"B. tech"`
- **Ticket Notch & Perforation:**
  - Circular cutouts (radius 12dp) indented into both left and right edges at y ≈ 225dp.
  - Connecting horizontal dotted perforation line.
- **Bottom Verification Row:**
  - Left: Info icon (`ic_info.svg`, 16x16dp) + `"Info"` caption, with expiration notice `"Valid Until 01 Jan 27 09:15:00"` below.
  - Center: QR code matrix (`ic_qrcode.svg`, 35x34dp) over serial label `"No . 1234567890"`.
  - Right: Download icon (`ic_download.svg`, 16x16dp) + `"Download"` caption.

### 5.5 Recent Pass Section
History feed of past passes:
- **Section Heading:** `"Recent Pass"` in Inter SemiBold 26sp, `#000000`.
- **Card Items:** 358 x 80 dp, `#FAFAFA` fill, 1px `#E8E8E8` border, 15dp corner radius, featuring ticket notches on left/right edges:
  - **Status Badge (Left):**
    - Completed / Returned: 50x50 dp black circular checkmark icon (`ic_returned.svg`).
    - Alert / Overdue: 50x50 dp warning hazard triangle with exclamation mark (`ic_notreturned.svg`).
  - **Middle Info:**
    - Student Name: `"Lorem Ipsum"` in Inter SemiBold 16sp.
    - Status Caption: `"Returned"` in Inter Medium 12sp (`#737373`).
    - Expiry: `"Valid Until 01 Jan 26"` in Inter Regular 9sp (`#737373`).
  - **Right Info:**
    - Duration: `"5 min"` in Inter SemiBold 16sp.
    - Time Slot: `"09:00 AM - 09:15 AM"` in Inter Regular 9sp (`#737373`).

---

## 6. Assets & Icons Mapping

All assets are located in `Teacher/icons/` and `restroomPassIcon/`:

| Asset File | Size | Used for | Visual Description |
|---|---|---|---|
| `ic_chevron_back.svg` | 30 x 30 dp | Header navigation | Left-pointing arrow chevron |
| `ic_running.svg` | 26 x 26 dp | Active pass timeline | Running figure silhouette |
| `ic_info.svg` | 16 x 16 dp | Active ticket bottom left | Letter "i" in circle |
| `ic_qrcode.svg` | 35 x 34 dp | Active ticket bottom center | QR matrix code |
| `ic_download.svg` | 16 x 16 dp | Active ticket bottom right | Tray with downward arrow |
| `ic_returned.svg` | 50 x 50 dp | Recent pass card (Returned) | Black circle with white checkmark |
| `ic_notreturned.svg` | 50 x 50 dp | Recent pass card (Overdue/Alert) | Triangle warning icon with exclamation mark |
| `ic_circle_plus.svg` | 50 x 50 dp | Issue button | White circle enclosing orange plus |

---

## 7. Behavior & Interaction Notes

1. **Back Navigation:** Tapping the chevron navigates back to the Teacher Home or Attendance screen.
2. **Issue Pass Action:** Tapping `"Issue a Supplementary Sheet"` (or `"Issue Pass"`) opens a student selector or modal to assign an active pass to a student.
3. **Live Countdown:** The `"15 minutes 00 second"` timer ticks down in real time. When it reaches `00:00`, the active card transitions from "Active" to "Overdue" status, updating the summary cards counter.
4. **Report Action:** Tapping `"Report"` brings up a confirmation sheet to alert hall supervisors or invigilator runners about an overdue or suspicious pass duration.
5. **Download Action:** Tapping `"Download"` generates a printable or shareable pass slip.

---

## 8. Build Notes (Jetpack Compose Implementation)

- **Ticket Notch Shape (Compose Custom Shape):**
  Implement the ticket card cutouts using a custom `Shape` with `Path` operations:
  ```kotlin
  class TicketShape(
      val cornerRadius: Dp = 10.dp,
      val notchRadius: Dp = 12.dp,
      val notchTopOffset: Dp = 225.dp
  ) : Shape {
      override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
          val path = Path().apply {
              // Draw rounded rect with semicircular cutouts on left and right edges at notchTopOffset
          }
          return Outline.Generic(path)
      }
  }
  ```
- **Reuse Components:**
  - Status cards share the exact same UI as `AttendanceComponents.kt` (`StatusCard`).
  - Header reuses `ScreenHeader` or `LineUnderlinedText`.
  - Issue button reuses `IssuePass` button from `SupplementComponents.kt`.

---

## 9. Observations & Open Questions

- **Button Label Discrepancy:** The Figma design explicitly has `"Issue a Supplementary Sheet"` inside the button on the Restroom Pass screen. This is a design copy-paste artifact; in production, this should read `"Issue a Restroom Pass"`.
- **Single Active Pass:** The design shows one active pass card. If multiple students are allowed out simultaneously (e.g. 1 male, 1 female), the Active Pass section should become a scrollable list or carousel.
