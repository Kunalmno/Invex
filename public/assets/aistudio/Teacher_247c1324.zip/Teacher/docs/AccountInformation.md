# Account Information (Teacher)

Source: your screenshot + AccountInformation.xml (390 x 844, bg #EBEBEB). Figma MCP unavailable, so values marked (est.) come from the screenshot. No new icons.

## Layout
| Item | Value |
|---|---|
| Breadcrumb | "Settings /" Inter SemiBold 14 (est.), #737373, tap = back |
| Header | chevron 32 (`ic_chevron_back`) + "Account Information" Pixelify SemiBold 36, orange underline 4 / offset 4. 8 below the breadcrumb |
| Fields x4 | Name, Registration Number, Phone Number, Email. Label Inter Medium 16 black, 8 gap, input 44 high, radius 12 (est.), fill #EEEEEE (est.), 1dp border #C9C9C9 (est.), text padding 12. Gap between groups 20 |
| Buttons | SAVE #171717 (SoftWhite text) and CANCEL #D9D9D9 (black text), 60 high, radius 12 (est.), equal width (165 at 390), gap 28, Inter SemiBold 20 (est.). 32 below the last field (24 + 8) |

Side padding 16, 24 between header, fields and buttons. Page scrolls and moves up with the keyboard.

## Behavior
- Settings > Account Information opens this screen.
- Keyboards: Phone number = phone, Email = email (last field has Done).
- SAVE keeps the edits (backend call is a TODO) and goes back. CANCEL drops unsaved edits and goes back.
- Fields start empty as in the design. TODO: load the real profile.

## Open
- No validation or error states are designed (empty name, bad email, phone length).
- Are all four fields editable? Registration Number may need to be read-only.
- Field fill and border colors are estimated from the screenshot.
