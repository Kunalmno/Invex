# Verify Admit Card (Teacher)

Source: your screenshot + verifyAdmitCard.xml (390 x 844, bg #EBEBEB). Figma MCP unavailable, so values marked (est.) come from the screenshot.

## Layout
| Item | Value |
|---|---|
| Header | chevron = existing `ic_chevron_back` (32), `ic_admit_card_heading` 40 (circle inside), "Verify Admit Card" Pixelify SemiBold 36, orange underline 4. Side padding 12 so the title fits on one line |
| Tabs | tray 52 high, radius 8, #E8E8E8 (est.), padding 16; two tabs 130 x 40, gap 12; selected Orange + SoftWhite text, other SoftWhite + black; Inter SemiBold 18 (est.) |
| Gap tabs to card | 60 (design 61) |
| Scan card | 358 wide, radius 8, faint #E8E8E8 fill/border (est.), padding 20 / 36 |
| Scan window | 220 x 240, radius 16. **Live camera** instead of the old SoftWhite box |
| Hint | Inter Medium 12/16, black, left aligned (was justified) |
| Button | 52 high, radius 12 (est.), Orange; existing `ic_qrcode` tinted SoftWhite (32) + "Scan the Student" Inter SemiBold 18 (est.), 24 apart, centered; 32 from the bottom |

## Behavior
- Opening the screen asks for camera permission. Once granted, the back camera starts and scans automatically.
- The camera reads **QR codes only** (ML Kit, format limited to QR). The orange viewfinder corners (`ic_qr_scanning`) sit over the picture.
- First QR read: scanning stops, the hint changes to "QR Code read. Tap Scan the Student to scan the next one." and the code is stored in `lastScan`. **Verification with the backend is a TODO.**
- "Scan the Student" restarts scanning.
- No permission / not scanning: the window shows the viewfinder icon and a line of text ("Allow camera access" opens the permission prompt).
- Students tab: not designed, shows "Students list coming soon".
- Exam Details > Verify Admit Card opens this screen.

## Needs (add yourself)
- Gradle: `androidx.camera:camera-camera2`, `camera-lifecycle`, `camera-view` (same version, e.g. 1.3.4) and `com.google.mlkit:barcode-scanning:17.3.0`.
- Manifest: `<uses-permission android:name="android.permission.CAMERA" />` and `<uses-feature android:name="android.hardware.camera" android:required="false" />`.

## Open
- What the Students tab shows; what happens after a code is read (result design, valid/invalid states).
- Copy for the "QR Code read" and "Allow camera access" lines is mine.
- Scan window is only 220 x 240 as designed; a larger camera area may scan more easily.
