# Broadcasts list and Broadcast page (Teacher, bottom sheets over Dashboard)

Source: your two screenshots + broadcasts.xml + BroadcastswithSpecificLink.xml (390 x 844) + `ic_arrow_over.svg`. Figma MCP unavailable, so values marked (est.) come from the screenshots.

## How they open (Dashboard)
- Tap the **"Broadcasts"** heading on the Dashboard -> the **list** sheet.
- Tap a **broadcast row** on the Dashboard ("view ↗") -> that broadcast's **own page** sheet directly.
- Tap a row inside the list sheet -> that broadcast's own page.
- Swipe down or tap outside: back to the Dashboard (from any sheet; there is no "back to list" in the design).
- Circulars are unchanged (tap does nothing yet, not designed).

The grey area above each sheet in Figma is the Dashboard behind the scrim, so these are sheets, not screens.

## Sheet (both)
| Item | Value |
|---|---|
| Container | `ModalBottomSheet`, SoftWhite #F7F9F7, top radius 16, no drag handle, 58% of screen high (491 of 844), scrolls if longer |
| Padding | 20 sides, 28 top, 24 bottom |
| Title | Pixelify SemiBold 36 (est.), orange underline 4 / offset 4, 12 gap below |

## List sheet
- Each item: heading Inter SemiBold 16, sub line Inter Medium 14, snippet line Inter Medium 14 with `ic_arrow_over` (24, glyph 12) at the end. Lines 22 high. Padding 8 sides, 20 top, 16 bottom (item pitch 102).
- 1dp black divider under every item (including the last).
- Whole row is tappable.

## Broadcast page sheet
- Title = the broadcast heading.
- Body Inter Medium 14 / 22, indented 24 from the left and 48 from the right (design width ~278), left aligned (was justified).
- "Broadcasted By : Admin" Inter Medium 14, 24 below the body, at the sheet's left edge.

## Data
- Sample data in `BroadcastsViewModel`: three broadcasts with ids b1 to b3, matching the Dashboard feed rows. TODO: load from the backend and match Dashboard rows by id.
- A "link" is not in the design: if a broadcast carries a web link, tell me where it should show (for example, an extra row under the body).

## Open
- Tapping the arrow inside a list row does the same as tapping the row.
- No empty state (no broadcasts) and no loading state.
- Title size 36 is a guess from the screenshot.
