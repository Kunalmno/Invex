# Onboarding (Teacher Page)

Design spec for the **OnboardingView** frame of the InvEx Figma file. It holds three onboarding screens: **FirstOnboarding**, **SecondOnboarding** and **ThirdOnboarding**.

- **Figma file:** InvEx (`UPA9x8osa59kxcwCNlfAAh`)
- **Node:** `302:73` (Teacher page > OnboardingView)
- **Link:** https://www.figma.com/design/UPA9x8osa59kxcwCNlfAAh/InvEx?node-id=302-73
- **Purpose:** a three-step intro shown after the loading screen: illustration, progress indicator, title and description, and Skip / Next buttons. The last screen has one Start button.

> **Sources:** the first and second screens come from Figma design data. The third screen comes from Figma structure and text plus the designer's uploaded screenshot, `ThirdOnboarding.xml` and `ic_third_Onboarding.svg`. From now on, designs reach the spec as uploaded images and sizes, because the Figma tool limit was reached.

---

## 1. Frame Overview

| Screen | Node | Size |
|---|---|---|
| FirstOnboarding | `363:119` | 390 x 844 reference |
| SecondOnboarding | `512:184` | 390 x 844 reference |
| ThirdOnboarding | `512:202` | 390 x 844 reference |

390 is the reference width for the whole project. Code is fluid so it works on most devices.

Each screen is a centered column with a 32px gap. Order, top to bottom: illustration circle, progress indicator, description, buttons.

| Property | Value |
|---|---|
| Background | `MobileBackground` `#ebebeb` (always, whatever the Figma frame uses) |
| Border / radius | Frame only (`#e8e8e8`, 15px). Not used in the app |
| Padding | 90 top, 30 bottom, 32 sides in Figma |

`ThirdOnboarding.xml` is only the frame background: `#EBEBEB` fill with a 2px `#E8E8E8` outline and 15px corners. The app doesn't need it.

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#ebebeb` | Screen background |
| `blue whale` | `#0070bb` | First screen accent |
| `IconColor` | `#171717` | Second screen accent, Next / Start fill, Skip text |
| `orange` | `#ed451f` | Third screen accent |
| `SoftWhite` | `#f7f9f7` | Illustration color |
| `TableHeaderText` | `#737373` | Description text |
| `default` | `#ffffff` | Next / Start text |

Hard-coded in Figma: `#ececec` inactive indicator, `#d9d9d9` Skip fill, `#000000` titles and indicator borders.

**Accent:** each screen has one accent color, used for the circle, the active indicator square and the title underline: blue, then dark, then orange.

---

## 3. Typography

| Use | Font | Weight | Size / Line height | Extra |
|---|---|---|---|---|
| Title | Pixelify Sans | SemiBold | 26 / 40 | left aligned, underlined per line, letter spacing 0 |
| Description | Inter | Medium | 14 / 25 | `TableHeaderText`, left aligned |
| Button label | Inter | Medium | 20 / 25 | |

---

## 4. Shared Components

### 4.1 Illustration circle

- Same size on all three screens: **248 x 248** (Figma had 250, 250 and 240 high).
- Fill is the screen accent.
- The illustration is centered exactly in the circle, with no left/right offset.
- All illustrations are SoftWhite line art. The third SVG's fill is `#F7F9F7`.

### 4.2 Illustration size

The three drawings are different shapes. Measured from the uploaded SVGs (all three are filled `#F7F9F7`):

| Screen | Drawing | SVG size | Drawing itself | Margin inside the SVG |
|---|---|---|---|---|
| First | Student with notebook | 200 x 160 | 189 x 149 | about 5 to 6 |
| Second | Person with arms stretched | 200 x 150 | 182 x 136 | about 7 to 9 |
| Third | Person with clock and clipboard | 150 x 150 | 136 x 136 | about 7 |

Rule for the code: each drawing is cropped to its own bounds and **fitted** (never stretched) into the same **168 x 152** box, centered in the circle. Result: the drawn sizes are 168 x 133, 168 x 125 and 152 x 152, whose areas are within about 5% of each other. A square box would have made the wide drawings look smaller than the third.

Each page also has an `illustrationScale` value (1 = the shared box) for fine adjustment on a real device.

### 4.3 Progress indicator

- Three squares, **20 x 20**, gap 32, 1px black border, 4px radius.
- The square for the **current screen** is filled with the accent; the other two are `#ececec`.
- The indicator moves with the screen: first square on screen 1, second on screen 2, third on screen 3.

### 4.4 Description

- Width 300 (max), gap 16 between title and body.
- Title: Pixelify Sans SemiBold 26/40, black, left aligned, with a 2px accent line under **each wrapped line**, as drawn in Figma.
- Body: Inter Medium 14/25, left aligned.
- The block keeps the same height on every screen so nothing jumps between screens.

### 4.5 Buttons

| Button | Size | Fill | Label |
|---|---|---|---|
| Skip | 140 x 60, radius 16 | `#d9d9d9` | "Skip", Inter Medium 20, `IconColor` |
| Next / Start | 140 x 60, radius 16 | `IconColor` | Inter Medium 20, white |

- Skip and Next sit side by side with a 40px gap. On the last screen only Start is shown, centered.

---

## 5. The Three Screens

| | First (`363:119`) | Second (`512:184`) | Third (`512:202`) |
|---|---|---|---|
| Accent / circle | `blue whale` | `IconColor` | `orange` |
| Active indicator | 1st | 2nd | 3rd |
| Illustration node | `275:80` | `275:85` | `275:89` |
| Title | "Track your Exams and seats" | "Every Exam Well Organized" | "Your duties, right on time" |
| Body | "Stay informed about your upcoming exams, schedules, and seating arrangements." | "Keep exam schedules, room assignments, and invigilation duties organized in one place." | "Get timely updates on invigilation assignments, room details, and important exam announcements." |
| Buttons | Skip, Next | Skip, Next | Start |

Corrected layer names (Figma still has the old names, to be changed by the designer):

| Node | Figma name | Name used in spec and code |
|---|---|---|
| `302:74` | 1 | FirstOnboardingCircle |
| `512:185` | Second | SecondOnboardingCircle |
| `512:203` | Second | ThirdOnboardingCircle |
| `275:89` | thirsOnboardingicon | ThirdOnboardingIcon |
| `363:123`, `363:118`, `363:122` and the matching ones on screens 2 and 3 | Rectangle 138, 136, 137 | IndicatorSquare1, 2, 3 (x = 0, 52, 104) |
| `512:217` | NextButton (on the third screen) | StartButton |

---

## 6. Assets

| Asset | Screen | Figma node | Drawable name |
|---|---|---|---|
| First illustration | First | `275:80` | `ic_onboarding_1` (in the zip as XML) |
| Second illustration | Second | `275:85` | `ic_onboarding_2` (in the zip as XML) |
| Third illustration | Third | `275:89` | `ic_onboarding_3` (in the zip as XML) |

The three drawables are the uploaded SVGs converted to Android vector XML, with the same paths and the empty margin cropped away.

---

## 7. Behavior Notes

- **Next** moves to the next screen. The indicator moves with it.
- **Skip** (screens 1 and 2) ends onboarding.
- **Start** (screen 3) ends onboarding. The destination (Login or Register) is decided by the caller.
- Swiping between screens works, and the system back button goes to the previous screen.
- Showing onboarding only on first launch needs a stored flag, which isn't built yet.

---

## 8. Build Notes

- **Compose:** `HorizontalPager` with one page composable and a list of three page models (`illustration`, `accent`, `title`, `body`).
- **Title underline:** Compose's `TextDecoration.Underline` can't change color or thickness, so each wrapped line is underlined by drawing under its measured text.
- **Illustration tint:** drawings are tinted SoftWhite so all three match. Remove the tint if an SVG ever has more than one color.

---

## 9. Grid-Adjusted Values

Rule: nearest multiple of 4, ties to the multiple of 8.

| Element | Figma | Code |
|---|---|---|
| Frame width | 395 | 390 reference, fluid in code |
| Circle | 250 / 240 high | 248 x 248 |
| Illustration box | 200x160, 200x150, 150x150 | 168 x 152, fitted |
| Screen padding top / bottom | 90 / 30 | 88 / 32 |
| Description gap | 18 | 16 |
| Button gap | 38 | 40 |
| Button radius | 15 | 16 |
| Description block min height | n/a | 176 |

Unchanged: indicator 20 x 20, radius 4, gap 32; buttons 140 x 60.

---

## 10. Resolved Decisions

| # | Question | Decision |
|---|---|---|
| 1 | Figma tool limit | The designer uploads images and sizes in a manual document until it resets. The spec and code are fitted from those. |
| 2 | Indicator | Moves with the screen. |
| 3 | Background | `MobileBackground` is `#ebebeb` everywhere, whatever the frame uses. |
| 4 | Frame width 395 | Always 390 as the project reference width. Code is fluid. |
| 5 | Justified text | Left aligned. |
| 6 | Letter spacing | 0 on every title. |
| 7 | Illustration sizes | Make all drawings look similar and centered in their circle (see 4.1 and 4.2). Done with cropped drawables and one shared fit box. |
| 8 | Layer name typos | Fixed in the spec and code, not in Figma. |
| 9 | Illustration color | SoftWhite, confirmed by the third SVG. |

## 11. Open Questions

- **Start destination:** resolved. Skip and Start both go to Login (`navigation/InvexApp.kt`). Onboarding is removed from the back stack, so Back on Login exits the app.
- **Look check on a device:** the drawn areas are equalized on paper. If one drawing still looks bigger or smaller, adjust its `illustrationScale`.
