# Supplement Sheets: Sign the Request (Teacher Page)

Design spec for the **"Supplement sheets with sign and request"** frame (the Figma frame is still named "...report", a typo) of the InvEx Figma file. It is the bottom sheet that opens when the teacher taps **Issue a Supplementary Sheet** on the SupplementSheet screen.

- **Figma file:** InvEx (`UPA9x8osa59kxcwCNlfAAh`)
- **Node:** `593:194` (Teacher page > Supplement sheets with sign and report)
- **Link:** https://www.figma.com/design/UPA9x8osa59kxcwCNlfAAh/InvEx?node-id=593-194
- **Opened from:** the orange "Issue a Supplementary Sheet" button in `SupplementSheet.md` (node `512:124`).
- **Purpose:** the teacher finds a student, signs the request (drawn or typed signature), confirms they supervised it, and issues a supplementary sheet.

---

## 1. Product Decisions (from the designer)

These decisions apply to this flow and to the "Sheets Issued" list on the SupplementSheet screen.

1. **Rows in "Sheets Issued" are display-only.** They are not clickable and do not open a details popup. The row already shows everything needed.
2. **More sheets for the same student = increment the number.** Requesting another sheet for a student who is already in the list increases that student's sheet count. It does not create a new row.
3. **Request metadata is backend-only.** Details such as the time of the request are recorded by the backend. No UI is needed for them.
4. **"Request" is not a feature.** The word describes what the sheet does: it creates a request for a supplement sheet. (The frame name said "report" by mistake.)
5. **Spacing grid.** All spacing and sizes sit on a 4px grid (4, 8, 12, 16, 20, 24 ...). Anything off-grid is rounded to the nearest multiple of 4, ties going to the multiple of 8. This applies to every screen.

---

## 2. Frame

| Property | Value |
|---|---|
| Size | 390 x 844 (mobile) |
| Background | `#ebebeb` (plain grey behind the sheet; the underlying screen is not drawn) |
| Border | 1px `OutlineShadow` `#e8e8e8` |
| Corner radius | 15px, content clipped |

### The sheet ("E-signature", node `593:199`)

| Property | Value |
|---|---|
| Position | x 0, y 143 |
| Size | 390 x 706 |
| Fill | `SoftWhite` `#f7f9f7` |
| Corner radius | 15px |
| Layout | Vertical stack, 16px gap |
| Padding | 20px horizontal, 24px vertical |

Content width inside the sheet is 350px.

---

## 3. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `SoftWhite` | `#f7f9f7` | Sheet fill, text on the Sign button |
| `IconColor` | `#171717` | Sign button fill |
| `ComboText` | `#0a0a0a` | Sheet heading text |
| `TableRowInteraction` | `#fafafa` | Search bar and student row fill |
| `OutlineShadow` | `#e8e8e8` | Borders |
| `TableHeaderText` | `#737373` | Back / Clear / Save signature, sub label |

Not tokenized in Figma (hard-coded values):

| Value | Used for |
|---|---|
| `#ebebeb` | Frame background (same value as `MobileBackground`, but not linked) |
| `#ed451f` | Underline under the heading |
| `#0070bb` | Underline under the active tab ("Draw") |
| `#eaeaea` | Signature box fill |
| `#d9d9d9` | "Resolved" pill |
| `#f4696b` | Warning banner fill |
| `#ffffff` | Consent card fill, Cancel button fill |
| `#040404` | "Sign the Request" heading |

---

## 4. Typography

| Use | Font | Weight | Size / Line height | Extra |
|---|---|---|---|---|
| Sheet heading ("Supplement Sheets") | Pixelify Sans | SemiBold | 36 / 40 | letter spacing -2px, underline in `#ed451f` (thickness 10% of font size) |
| "Sign the Request" | Inter | SemiBold | 22 / 32 | |
| Tabs ("Draw", "Type") | Pixelify Sans | Medium | 20 / 20 | active tab underlined in `#0070bb` |
| Search placeholder, student name | Inter | Medium | 16 / normal | |
| Row count | Inter | Medium | 20 / normal | |
| Row meta | Inter | Medium | 10 / normal | |
| "Resolved" pill text | Inter | Medium | 8 / 8 | |
| Back, Clear, Save signature | Inter | Medium | 15 / 15 | `TableHeaderText` |
| Sub label | Inter | Medium | 10 / 15 | `TableHeaderText` |
| Consent text, warning text | Inter | Regular | 10 / 12 (consent), 10 / 10 (warning) | justified |
| Cancel / Sign buttons | Inter | Medium | 14 / 30 | letter spacing -1px |

---

## 5. Layout Structure

```
Supplement sheets with sign and report (593:194)
└── E-signature (593:199)                      390x706 sheet, 16px gap
    ├── heading and tabs (593:200)              "Supplement Sheets", 316x49
    ├── Search Inbox (601:67)                   350x55
    ├── Row One (601:72)                        350x55, student result
    ├── "Sign the Request" (601:79)
    ├── Tabs (593:205)                          "Draw" | "Type", 24px gap
    ├── sign and typing box (593:208)           350x160
    │   ├── Line 9 (593:209)                    246 wide baseline
    │   └── Back and Save (593:210)             311x15
    │       ├── Back and Clear (593:211)
    │       │   ├── Back (593:212)              icon + label
    │       │   └── Clear (593:217)             icon + label
    │       └── "Save signature" (593:222)
    ├── Sub Label (593:223)                     one line, 10px
    ├── warning before signing (593:224)        350x88 card
    │   ├── checkbox (593:225)                  switch + consent text
    │   └── Warning (593:229)                   red banner
    └── Buttons (593:234)                       Cancel + Sign, 12px gap
        ├── Cancel button (593:235)
        └── Sign button (593:237)
```

Vertical positions inside the sheet (each section is 16px apart): heading y24, search y89, row y160, "Sign the Request" y231, tabs y279, signature box y315, sub label y491, consent card y522, buttons y626.

---

## 6. Components

### 6.1 Sheet heading

"Supplement Sheets" in Pixelify Sans SemiBold 36px, `ComboText`, letter spacing -2px. It has an **orange underline** (`#ed451f`) at about 3.6px thick. This is different from the plain underlines on the other screens, so it needs a custom-drawn underline in Compose.

### 6.2 Search bar

Same component as on the SupplementSheet and Attendance screens, but 350px wide here: 55px tall, `TableRowInteraction` fill, 1px `OutlineShadow` border, 15px radius, 34x34 magnifier icon, placeholder "Search for the students" (Inter Medium 16px).

### 6.3 Student result row

Same row as the list on the SupplementSheet screen, 350px wide: name (Inter Medium 16), meta "B.tech | 3rd Year | 7045" (Inter Medium 10), sheet count "01" (Inter Medium 20) and a "Resolved" pill (`#d9d9d9`, 60x15). It shows the student that matches the search. Only one row is designed; a selected state is not designed.

### 6.4 "Sign the Request" section

- Heading: "Sign the Request", Inter SemiBold 22/32, `#040404`.
- **Tabs:** "Draw" and "Type", 24px apart, Pixelify Sans Medium 20px. The active tab ("Draw") has a `#0070bb` underline.
- **Signature box:** 350x160, `#eaeaea` fill, 15px radius, 16px padding.
  - A 246px-wide, 1px baseline line is centered horizontally, 79px from the top of the box. The signature is drawn above it.
  - A control row sits 16px from the bottom: **Back** (15x15 arrow icon + label), 12px gap, **Clear** (15x15 eraser icon + label), then **Save signature** pushed to the right. Total row width 311px, centered. All text is `TableHeaderText` Inter Medium 15px.
- **Sub label** under the box: "This Supplement Sheet will be signed by and sent to subsequent signee." (Inter Medium 10px, `TableHeaderText`).

### 6.5 Consent card ("warning before signing")

350x88, white fill, 1px `OutlineShadow` border, 10px radius, 12px horizontal and 8px vertical padding, 12px gap, content centered.

- **Consent row:** a 21x12 toggle switch (shown in the off state: grey track, white knob at left), 8px gap, then the text: "By signing, I confirm that the student requires an additional answer sheet and this request is made under my supervision." (Inter Regular 10/12, justified, 280px wide).
- **Warning banner:** 324x24, `#f4696b` fill, 5px radius, 12px gap, 14x14 alert icon (circle with an exclamation mark), then "Please confirm you agree to all terms before signing." (Inter Regular 10/10, justified).

### 6.6 Buttons

Left-aligned row, 12px gap, each 30px tall with 12px horizontal padding and 10px radius.

| Button | Fill | Text |
|---|---|---|
| Cancel (66 wide) | white | "Cancel", Inter Medium 14, black |
| Sign (189 wide) | `IconColor` `#171717` | "Sign the Supplement Sheets", Inter Medium 14, `SoftWhite` |

Both have letter spacing -1px.

---

## 7. Assets

| Asset | Where | Size | Figma node |
|---|---|---|---|
| Search magnifier | Search bar | 34x34 | Frame `601:68` (same icon as `ic_search`, reuse it) |
| Back arrow | Signature box | 15x15 | Frame `593:213` |
| Clear (eraser) | Signature box | 15x15 | Frame `593:218` |
| Alert icon | Warning banner | 14x14 | Frame `593:230` |

The toggle switch (`593:226`, 21x12), the baseline (`593:209`) and the underlines can be drawn in code, so they don't need exporting.

---

## 8. Flow and Behavior

1. Teacher taps **Issue a Supplementary Sheet** on the SupplementSheet screen. This sheet opens over it.
2. The teacher searches for a student using the search bar. Matching students appear below it.
3. The teacher signs in the box: draw with a finger on the **Draw** tab, or type a name on the **Type** tab.
   - **Back** undoes the last stroke, **Clear** wipes the box, **Save signature** keeps the signature.
4. The teacher turns on the consent switch.
5. Tapping **Sign the Supplement Sheets** with the switch off shows the red warning banner. With the switch on, the request is submitted.
6. On submit, the student's sheet count goes up by one on the SupplementSheet screen (a new row with 01 if the student wasn't listed yet). The backend stores the metadata (time, signer).
7. **Cancel** closes the sheet without issuing anything.

Steps 3 to 5 are inferred from the layout. Back/Clear/Save and the warning banner behavior are not written anywhere in Figma.

---

## 9. Build Notes

- **Bottom sheet:** a Material 3 `ModalBottomSheet` works if you set the container color to `SoftWhite`, the shape to 15dp rounded corners and hide the default drag handle. This keeps Material's defaults from changing the design.
- **Signature drawing:** a Compose `Canvas` with `pointerInput` and `detectDragGestures`. Keep strokes as a list of paths so Back can remove the last one and Clear can empty the list.
- **Orange and blue underlines:** `TextDecoration.Underline` can't set the color or thickness. Draw the line with `Modifier.drawBehind`.
- **Reuse:** `InvexSearchBar` and `StudentRow` already exist. They are 354px wide on the other screens and 350px here, so let them fill the available width instead of using fixed widths.
- **State changes in the existing code:** `SupplementViewModel` needs an `issueSheet(student)` that increments the count of an existing student or adds a new one. Rows stay non-clickable, as already built.

---

## 10. Resolved Decisions

Answers from the designer to the open questions in the first draft.

| # | Question | Decision |
|---|---|---|
| 1 | "Report" in the frame name | A typo for **request**. See product decision 4. |
| 2 | Type tab | Follows the Draw layout exactly. The middle line is the shared baseline: a drawn signature is free-form above it, a typed name **sits on the line like an underline**. |
| 3 | Warning banner visible in the design | Shown only to demonstrate what happens when someone signs without agreeing. In code it appears after a refused sign attempt. |
| 4 | Sheet 5px past the bottom | Miscalculation, already fixed by the designer. |
| 5 | Spacing | 4px grid, see section 11. |
| 6 | Warning red vs status red | The banner color was picked quickly. Use the status red `#f24e51`, so the app has one red. |
| 7 | Weak contrast of Cancel | Colors weren't final. Cancel keeps its white fill and gets the 1px `OutlineShadow` border used by the cards on other screens. The off-state switch uses `#d9d9d9` (same grey as the pills). |
| 8 | Baseline (Line 9) color | `#737373` (`TableHeaderText`). |

---

## 11. Grid-Adjusted Values (what the code uses)

| Element | Figma | Code |
|---|---|---|
| Sheet corner radius | 15 | 16 |
| Heading underline thickness / gap | 3.6 / 2 | 4 / 4 |
| Tab underline gap | 1 | 4 |
| Signature box radius | 15 | 16 |
| Baseline: y from top, width | 79, 246 | 80, 248 |
| Control row width | 311 | 312 |
| Back / Clear icons | 15 | 16 |
| Switch | 21 x 12, knob 10 | 20 x 12, knob 8 |
| Banner radius, alert icon | 5, 14 | 4, 16 |
| Consent card radius | 10 | 8 |
| Buttons: height, radius | 30, 10 | 32, 8 |
| Search bar, student row | 55 high, 15 radius | 56 high, 16 radius |
| Pill | 60 x 15 | 60 x 16 |
| Gap between search bar and first row | 18 | 16 |

Typography sizes (22, 15, 10 and so on) and 1 to 2px lines (borders, signature stroke) are not spacing and are left as drawn.
