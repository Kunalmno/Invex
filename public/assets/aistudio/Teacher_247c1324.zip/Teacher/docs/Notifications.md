# Notifications (Teacher)

Source: your screenshot + notifications.xml (390 x 844, bg #EBEBEB). Figma MCP unavailable, so values marked (est.) come from the screenshot. No new icons.

## Layout (side padding 16)
| Item | Value |
|---|---|
| Header | same as Account Information: "Settings /" breadcrumb + chevron + "Notifications" (Pixelify SemiBold 36, orange underline). Now one shared `SettingsSubHeader` |
| Subtitle | "Get notification about exams, you can turn that off any time." Inter Medium 12, #737373. 20 below the header |
| Email Notification | heading Inter SemiBold 18 (est.) black; text Inter Medium 14 #737373; gap 8 |
| Switch | 84 x 36 pill, #D9D9D9, 1.5dp black outline, white 30 thumb with black outline (right = on). Custom (Material Switch would change the look) |
| Option rows x3 | title Inter SemiBold 16 black + checkbox 28 (2dp black outline, radius 8) at the end; description Inter Medium 14 / line height 26, #737373, max width 300, left aligned (was justified); title-to-description 8. Gap between options 24 |
| Buttons | SAVE / CANCEL, same as Account Information (60 high, gap 28). 20 below the last option |

Page scrolls. Section gap 20; email block to first option 20 (design 28).

## Behavior
- Settings > Notifications opens this screen.
- Defaults as drawn: email on, the three checkboxes empty. A ticked checkbox is black with a light check mark (not drawn in Figma).
- SAVE keeps the choices (backend TODO) and goes back. CANCEL drops unsaved changes and goes back.

## Open
- Off look of the switch (thumb left, same track) is my assumption.
- Should turning email off disable the options? Not designed; they stay independent.
- Copy typos in Figma ("improvise user experience", "Preferred notification") are kept as designed; fix them in Figma if wanted.
- Shared pieces: `SettingsSubHeader` is in ui/components; the SAVE/CANCEL buttons are `AccountActionButtons` from the accountinfo package.
