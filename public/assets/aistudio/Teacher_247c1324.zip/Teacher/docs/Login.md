# Login (Teacher/Student shared entry)

Source: your screenshot + LoginView.xml / LoginViewDetails.xml. Reference width 390. Background `MobileBackground` #ebebeb.
Figma MCP is unavailable, so items marked **(estimate)** come from the screenshot, not from measured data. Please check them on a device.

## 1. Layout (top to bottom, centered vertically, 24 gap)
| Item | Figma | In code |
|---|---|---|
| Logo block | 241 x 78 | 80 (48 wordmark + 8 + 24 subtext) |
| Role selector | ~136 x 40 **(estimate)** | 136 x 40, radius 8, fill PillGrey |
| Field group x2 | 358 x 74 | 72 = label 24 + 8 + input 40 |
| Login button | 358 x 40 | full width (358 at 390), radius 8, Orange |
| Terms | 250 x 48 | 248 wide, left aligned |

Screen side padding 16 (390 - 358 = 32). Whole column scrolls only if the keyboard or a short screen needs it.

## 2. Content
- "InvEx" wordmark, Pixelify SemiBold 48/48 **(estimate)**, black.
- "Already have an account ?" Inter Medium 14/24, black, then "Sign up" with an orange 2dp underline (offset 4 -> Register).
- Selector: "Faculty" Inter SemiBold 16 + `ic_unfold_more` 16dp. Menu: Faculty / Student **(Student assumed)**.
- Field labels: "Faculty ID" (becomes "Student ID") and "Password", Inter Medium 16/24, orange 2dp underline, offset 4.
- Input: 40 high, radius 8, 1dp #737373 border, transparent fill **(estimate)**, text Body16 black, 12 side padding. Password is masked.
- Button: "Login", Inter Bold 16, SoftWhite on Orange **(text color estimate)**.
- Terms: "By clicking continue, you agree to our Terms of Service and Privacy Policy." Inter Medium 14/16, #737373. Was justified, now left aligned.

## 3. Grid rounding
65/74 -> 64/72 style rounding applied: 74 -> 72, 78 -> 80, 250 -> 248. Type sizes and 1-2dp lines exempt.

## 4. Behavior
- Role change updates the first field label.
- Login currently continues without validation (no backend and no error/loading states designed). `LoginViewModel` has a TODO for it.
- After login: temporary route to Attendance. Real target (Faculty vs Student home) is open.
- Sign up: TODO, Register screen not designed yet.
- Onboarding Skip/Start -> Login; Login replaces onboarding in the back stack.

## 5. Needs
- Dependency: `androidx.navigation:navigation-compose`.
- Asset: `ic_unfold_more` (already imported).

## 6. Open questions
- Error states (wrong ID/password, empty fields) and a show/hide password toggle: not in the design.
- Is there a "Forgot password"? Not shown.
