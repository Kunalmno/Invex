# Register (Teacher/Student Account Creation)

Design spec for the **Register** (Sign Up) screen of the InvEx mobile application.

- **Sources:** 
  - Screenshot reference: Attached Register design (`media_1794211187124_e968eff9.png`)
  - Architectural & token parity: [Login.md](file:///c:/Users/abc/Saved%20Games/Notes/Invex/Teacher/Login.md)
  - Reference width: 390dp. Background: `MobileBackground` `#EBEBEB`.
- **Purpose:** New faculty and student account onboarding and registration. Mirrors the layout, token system, and interaction pattern of the Login screen, providing role selection (Faculty / Student), credential creation (ID, Create Password, Confirm Password), submission CTA ("Create your account"), and navigation back to Login ("Sign in").

---

## 1. Frame & Layout

| Property | Value |
|---|---|
| Reference Size | 390 x 844 dp (standard mobile canvas; extends scroll if keyboard opens) |
| Background | `MobileBackground` `#EBEBEB` |
| Corner Radius | 15dp |
| Border | 1px `OutlineShadow` `#E8E8E8` |
| Layout | Vertical stack, centered vertically, 24dp gap between top-level elements |
| Screen Padding | 16dp horizontal (390dp frame - 358dp content = 32dp total side margins) |
| Scroll Behavior | The whole column is centered on screen; scrolls smoothly with `imePadding()` and `verticalScroll()` when the software keyboard is active |

### Vertical Layout Flow (top to bottom, 24dp vertical gap):

| Element | Measured / Figma | In Code Implementation |
|---|---|---|
| **Logo & Subtext Block** | ~241 x 78 dp | 80dp high (48dp wordmark + 8dp gap + 24dp subtext row) |
| **Role Selector** | 136 x 40 dp | 136 x 40 dp, radius 8dp, fill `PillGrey` (`#D9D9D9` / `#EAEAEA`) |
| **Field 1 (ID)** | 358 x 72 dp | 72dp = label 24dp + 8dp gap + input field 40dp |
| **Field 2 (Create Password)** | 358 x 72 dp | 72dp = label 24dp + 8dp gap + input field 40dp |
| **Field 3 (Confirm Password)** | 358 x 72 dp | 72dp = label 24dp + 8dp gap + input field 40dp |
| **Register Button** | 358 x 40 dp (or 44dp) | Full width (358dp at 390dp), radius 8dp, fill `Orange` (`#ED451F`) |
| **Terms & Privacy** | ~250 x 50 dp | 250dp wide, centered alignment across 3 lines |

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#EBEBEB` | Screen background |
| `OutlineShadow` | `#E8E8E8` | Frame outline / subtle component borders |
| `Orange` | `#ED451F` | Accent color: "Sign in" underline, field label underlines, "Create your account" button background |
| `IconColor` / `Black` | `#000000` / `#171717` | Wordmark, field labels, role text, input text |
| `PillGrey` | `#D9D9D9` / `#EAEAEA` | Role selector background container |
| `TableHeaderText` | `#737373` | Input field borders / baseline dividers, terms legal disclaimer |
| `SoftWhite` | `#FFFFFF` / `#F7F9F7` | Text on the orange "Create your account" CTA button |

---

## 3. Typography

| Element | Font Family | Weight | Size / Line Height | Color & Style |
|---|---|---|---|---|
| **Wordmark** ("InvEx") | Pixelify Sans | SemiBold | 48sp / 48sp | `#000000`, center aligned |
| **Header Caption** ("Already have an account ?") | Inter | Medium | 14sp / 24sp | `#000000` |
| **Sign In Action** ("Sign in") | Inter | Medium | 14sp / 24sp | `#000000` with 2dp `Orange` underline (offset 4dp) |
| **Role Selector Label** ("Faculty" / "Student") | Inter | SemiBold | 16sp / 24sp | `#000000` |
| **Field Labels** ("Faculty ID", "Create Password", "Confirm Password") | Inter | Medium | 16sp / 24sp | `#000000` with 2dp `Orange` underline (offset 4dp) |
| **Input Value Text** | Inter | Medium | 16sp / normal | `#000000` (`Body16`) |
| **CTA Button** ("Create your account") | Inter | Bold | 16sp / 24sp | `SoftWhite` (`#FFFFFF`), center aligned |
| **Terms & Privacy Notice** | Inter | Medium / Regular | 13sp / 16sp | `#737373`, centered across 3 lines |

---

## 4. Layout Structure

```
Register Screen (390 x 844 dp)
└── Centered Column (358dp width, 24dp vertical gap)
    ├── Logo Block (358 x 80 dp)
    │   ├── Wordmark: "InvEx"                          (Pixelify Sans SemiBold 48sp, black)
    │   └── Subtext Row (horizontal, 4dp gap)
    │       ├── "Already have an account ?"             (Inter Medium 14sp, black)
    │       └── "Sign in"                               (Inter Medium 14sp, orange underline -> navigates to Login)
    ├── Role Selector (136 x 40 dp pill, fill #D9D9D9, radius 8dp)
    │   ├── Role Text: "Faculty"                        (Inter SemiBold 16sp)
    │   └── Chevron Glyph: ic_unfold_more               (16 x 16 dp)
    ├── Field Group 1: Faculty/Student ID (358 x 72 dp)
    │   ├── Label: "Faculty ID"                         (Inter Medium 16sp + 2dp orange underline)
    │   └── Input Field: 40dp high, radius 8dp, border 1dp #737373, placeholder / text
    ├── Field Group 2: Create Password (358 x 72 dp)
    │   ├── Label: "Create Password"                    (Inter Medium 16sp + 2dp orange underline)
    │   └── Input Field: 40dp high, radius 8dp, border 1dp #737373, masked password
    ├── Field Group 3: Confirm Password (358 x 72 dp)
    │   ├── Label: "Confirm Password"                   (Inter Medium 16sp + 2dp orange underline)
    │   └── Input Field: 40dp high, radius 8dp, border 1dp #737373, masked password
    ├── Register CTA Button (358 x 40-44 dp, radius 8dp, fill #ED451F)
    │   └── Label: "Create your account"                (Inter Bold 16sp, white)
    └── Legal Disclaimer (250 x 48 dp, centered column)
        └── "By clicking continue, you agree to
             our Terms of Service and Privacy
             Policy."                                   (Inter Medium 13sp/16sp, #737373, centered)
```

---

## 5. Component Breakdown

### 5.1 Logo & Header Block
- **Wordmark:** `"InvEx"` rendered in Pixelify Sans SemiBold 48sp, centered.
- **Switch Action Row:** 
  - Caption: `"Already have an account ?"` in Inter Medium 14sp, `#000000`.
  - Action Link: `"Sign in"` in Inter Medium 14sp with a 2dp orange underline bar (drawn with `LineUnderlinedText`, offset 4dp).
  - Interaction: Tapping `"Sign in"` pops back to or navigates to the Login screen.

### 5.2 Role Selector Pill
- **Size:** 136dp wide x 40dp high, 8dp corner radius, background `PillGrey` (`#D9D9D9` or `#EAEAEA`).
- **Contents:** `"Faculty"` (Inter SemiBold 16sp) + `ic_unfold_more` glyph (16x16dp) with 24dp spacing.
- **Options:** Dropdown menu offering `Faculty` and `Student`.
- **Dynamic Coupling:** Selecting `"Student"` updates the first input field's label from `"Faculty ID"` to `"Student ID"`.

### 5.3 Input Field Groups (x3)
Register has three input fields (compared to two in Login):
1. **Faculty ID / Student ID:**
   - Label: `"Faculty ID"` (or `"Student ID"`), Inter Medium 16sp with an orange underline.
   - Input Box: 40dp high, 8dp corner radius, 1dp border `#737373`, 12dp internal side padding.
   - Keyboard: `KeyboardType.Text` / `KeyboardType.Ascii`, `ImeAction.Next`.
2. **Create Password:**
   - Label: `"Create Password"`, Inter Medium 16sp with an orange underline.
   - Input Box: 40dp high, masked using `PasswordVisualTransformation()`.
   - Keyboard: `KeyboardType.Password`, `ImeAction.Next`.
3. **Confirm Password:**
   - Label: `"Confirm Password"`, Inter Medium 16sp with an orange underline.
   - Input Box: 40dp high, masked using `PasswordVisualTransformation()`.
   - Keyboard: `KeyboardType.Password`, `ImeAction.Done`.

### 5.4 "Create your account" CTA Button
- **Size:** Full width (358dp inside a 390dp screen), height 40dp to 44dp, corner radius 8dp.
- **Background:** `Orange` (`#ED451F`).
- **Label:** `"Create your account"` in Inter Bold 16sp, `SoftWhite` (`#FFFFFF`), centered.
- **Interaction:** Validates input fields and triggers user registration.

### 5.5 Terms of Service & Privacy Policy Disclaimer
- **Text:** 
  ```
  By clicking continue, you agree to
  our Terms of Service and Privacy
  Policy.
  ```
- **Styling:** Inter Medium 13sp / line-height 16sp, color `TableHeaderText` (`#737373`).
- **Alignment:** Center aligned (unlike Login where it was left-aligned; in the Register screenshot it is distinctly centered across 3 balanced lines within a ~250dp bounding box).

---

## 6. Grid Rounding & Sizing Standards

- Consistent 8dp base grid: Field heights 40dp, label height 24dp, gap 8dp -> total group height 72dp.
- Card / Button widths: 358dp on 390dp frame (16dp side padding).
- Underline offsets: 4dp below baseline for form labels and interactive action links.

---

## 7. Behavior & Validation

1. **Role Switch:**
   - Switching roles toggles between Faculty and Student modes.
   - Field label updates synchronously (`"Faculty ID"` ⟷ `"Student ID"`).
2. **Password Validation:**
   - On `"Create your account"` click:
     - Check for empty fields.
     - Validate that `"Create Password"` matches `"Confirm Password"`.
     - Enforce minimum password length (recommended: ≥ 6 or 8 characters).
3. **Navigation Transitions:**
   - `"Sign in"` click: Returns to Login screen (`nav.popBackStack()` or `nav.navigate(Route.Login)`).
   - Successful Registration: Navigates to Dashboard (`Route.Dashboard`) or logs the user in automatically, clearing the onboarding/auth stack.

---

## 8. Build Notes (Jetpack Compose Implementation)

- **Reuse Existing Components:**
  - `LineUnderlinedText` from `com.invex.app.ui.components.LineUnderlinedText`.
  - `RoleSelector` from `com.invex.app.login.RoleSelector` (or shared `ui.components`).
  - `LabeledField` can be reused directly for all 3 fields:
    ```kotlin
    LabeledField(
        label = if (state.role == UserRole.FACULTY) "Faculty ID" else "Student ID",
        value = state.userId,
        onValueChange = viewModel::onUserIdChange,
        imeAction = ImeAction.Next,
    )
    LabeledField(
        label = "Create Password",
        value = state.password,
        onValueChange = viewModel::onPasswordChange,
        visualTransformation = PasswordVisualTransformation(),
        keyboardType = KeyboardType.Password,
        imeAction = ImeAction.Next,
    )
    LabeledField(
        label = "Confirm Password",
        value = state.confirmPassword,
        onValueChange = viewModel::onConfirmPasswordChange,
        visualTransformation = PasswordVisualTransformation(),
        keyboardType = KeyboardType.Password,
        imeAction = ImeAction.Done,
    )
    ```
- **Navigation Integration:**
  - Add `Route.Register = "register"` to `navigation/InvexApp.kt`.
  - Login's `"Sign up"` navigates to `Route.Register`.
  - Register's `"Sign in"` navigates to `Route.Login`.

---

## 9. Observations & Open Questions

- **Password Reveal:** Neither Login nor Register shows an eye toggle for masking/unmasking passwords in Figma; consider adding a show/hide toggle for user convenience.
- **Backend API Error Handling:** Need visual error states for "Account already exists" and "Password mismatch".
- **Terms Links:** Confirm whether "Terms of Service" and "Privacy Policy" should be clickable links opening a webview or modal.
