# Exam Details (Teacher)

Source: your screenshot + examdetails.xml (390 x 1012, bg #EBEBEB). Figma MCP unavailable, so values marked (est.) come from the screenshot.

## Layout (top to bottom)
| Item | Value |
|---|---|
| Header | chevron 32, `ic_exam_details` 40 (circle is inside the drawable), "Exam Details" Pixelify SemiBold 36, orange underline 4 / offset 4 |
| "Courses Details" | Inter SemiBold 24/32 (est.); same style for "Room" and "Services" |
| Course cards x4 | 56 high, radius 8, SoftWhite, padding 8, gap 12. Left: "Course I" Inter SemiBold 10, name Inter Medium 16, grey 16 square. Right: "Students" Inter SemiBold 10, count Inter Medium 16 |
| Room drawing | `ic_full_room` 184 x 180, centered |
| Block / Room / Division | label Inter SemiBold 14 + value Inter Bold 24 (est.), 48 apart, centered |
| Services | 4 round icons 70 (circle inside drawable), label Inter Medium 10/16, 2 lines, 8 gap |
| Buttons | CANCEL grey #D9D9D9 / PROCEED #171717, 52 high, radius 12 (est.), Inter SemiBold 20 (est.), gap 16 |

Section gap 24, heading-to-content gap 12. Header and buttons stay fixed; the middle scrolls on short screens.

## Behavior
- Cancel = back. Proceed = Room View (my guess).
- Services: Supplement Sheet, Restroom Pass, Attendance open their screens. Verify Admit Card is a TODO (no screen).
- Dashboard room chips now open Exam Details (my guess).
- Label "Supplement Sheat" is a typo in Figma; code uses "Sheet".

## Open
- Meaning of the small grey square next to each course name (placeholder).
- Whether Proceed goes to Room View.
- Duties header underline: `ScreenHeader` underlines in text color, the Duties design shows orange.

## Assets
SVGs were converted to vector drawables with new names so they don't overwrite your existing ones: `ic_service_admit_card`, `ic_service_supplement_sheet`, `ic_service_restroom_pass`, `ic_service_attendance`, `ic_exam_details`, `ic_full_room`.
