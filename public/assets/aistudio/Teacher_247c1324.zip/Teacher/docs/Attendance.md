# Attendance (Teacher Page)

Design spec for the **Attendance** frame of the InvEx Figma file.

- **Figma file:** InvEx (`UPA9x8osa59kxcwCNlfAAh`)
- **Node:** `510:79` (Teacher page > Attendance)
- **Link:** https://www.figma.com/design/UPA9x8osa59kxcwCNlfAAh/InvEx?node-id=510-79
- **Purpose:** Teacher-facing mobile screen showing attendance for a selected course: Total / Present / Absent counts, a donut chart with a legend, and a searchable list of students.

---

## 1. Frame

| Property | Value |
|---|---|
| Size | 390 x 1086 (taller than a phone screen, so the content scrolls) |
| Background | `MobileBackground` `#ebebeb` |
| Border | 1px `OutlineShadow` `#e8e8e8` |
| Corner radius | 15px |
| Layout | Vertical stack, 24px gap |
| Padding | 60px top, 16px sides, 16px bottom |

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#ebebeb` | Screen background, analytics card fill |
| `OutlineShadow` | `#e8e8e8` | Borders on frame, cards, rows |
| `HoverSelect` | `#f5f5f5` | Status card fill |
| `TableRowInteraction` | `#fafafa` | Search bar and student row fill |
| `IconColor` | `#171717` | Page heading text |
| `light Brown` | `#6e473b` | Donut segment (dark brown) |
| `Mist` | `#beb5a9` | Donut segment (large, light) |
| `Pale Brown` | `#a78d78` | Donut segment (medium) |
| `SoftWhite` | `#f7f9f7` | Not used visibly in this frame |

Not tokenized in Figma (hard-coded values):

| Value | Used for |
|---|---|
| `#ed451f` | Orange circle behind the Attendance icon |
| `#66cd4c` / `#ffde7c` / `#f24e51` | Status dots for Total / Present / Absent (1px black border, 4px radius) |
| `#d9d9d9` | "Resolved" pill |
| `#d2d1d1` | Legend squares (12x12, 2px radius) |
| `#b4b4b4` | Chart value labels (20, 42, 20) |
| `#040404` | Section headings and legend text |
| `#0d0d0d` | Status card labels |

---

## 3. Typography

| Use | Font | Weight | Size / Line height |
|---|---|---|---|
| Page heading ("Attendance") | Pixelify Sans | SemiBold | 36 / 40, underlined |
| "All Courses" | Inter | Bold | 20 / 32 |
| "Analytics" | Inter | Bold | 26 / 32 |
| "Students" section heading | Inter | SemiBold | 26 / 32 |
| Status card label | Inter | SemiBold | 14 / 14 |
| Status card count | Inter | SemiBold | 24 / 24 |
| Legend caption ("Students") | Inter | Medium | 14 / 32 |
| Legend label | Inter | SemiBold | 14 / 32 |
| Legend count | Inter | SemiBold | 16 / 16 |
| Chart value labels | Inter | Regular | 12 / normal, `#b4b4b4` |
| Search placeholder, student name | Inter | Medium | 16 / normal |
| Row count | Inter | Medium | 20 / normal |
| Row meta | Inter | Medium | 10 / normal |
| "Resolved" pill text | Inter | Medium | 8 / 8 |

Note that "Analytics" is Bold but the "Students" heading below it is SemiBold, at the same 26px size.

---

## 4. Layout Structure

```
Attendance (510:79)
├── back icon and heading (513:221)
│   ├── chevron back (513:222)             30x30
│   └── icon and Heading (513:225)
│       ├── Attendance Icon (513:226)       40x40, orange circle
│       └── Heading (513:229)               "Attendance"
├── Courses and Card (510:78)              350 wide, 12px gap
│   ├── All Courses (510:75)                title + 24x24 dropdown icon, 8px gap
│   └── PassesStatusCard (507:308)          3 cards, 12px gap
│       ├── ActivePass (351:125)            "Total"
│       ├── ReturnedPass (351:120)          "Present"
│       └── OverduePass (351:115)           "Absent"
├── Analytics and Card (510:77)            354 wide, 12px gap
│   ├── "Analytics" (316:37)
│   └── AnalyticsCard (510:74)              354x418
│       ├── Chart (352:151)                 268x220, donut
│       └── students and label (508:73)     233 wide, 8px gap
│           ├── "Students" caption (318:41)
│           ├── Total Label (508:54)
│           ├── Present Label (508:63)
│           └── Absent Label (508:68)
└── Students Heading and Data (512:94)     354 wide, 12px gap
    ├── "Students" (512:95)
    └── Student data (512:96)               18px gap
        ├── Search Inbox (512:97)
        └── row Selection (512:102)         12px gap, 3 rows
```

---

## 5. Components

### 5.1 Header

Same pattern as the SupplementSheet screen.

- Horizontal row, 4px gap, vertically centered.
- **Chevron back:** 30x30, tap target to go back.
- **Icon + heading:** 8px gap.
  - Icon: 40x40 circle (25px radius), `#ed451f` fill, white bar-chart glyph. The glyph group has insets of 25% top/bottom and 12.5% left/right inside the circle.
  - Heading: "Attendance" in Pixelify Sans SemiBold 36px, `IconColor`, underlined.

### 5.2 Course selector (All Courses)

- Row with 8px gap: "All Courses" text (Inter Bold 20/32, `#040404`) and a 24x24 up/down chevron icon.
- Interactive: opens a course picker. "All Courses" is the default selection, and the counts, chart and student list should change with the chosen course.

### 5.3 Status cards (Total / Present / Absent)

Three cards in a row, 12px gap, 350px container.

Each card:
- 110x70, `HoverSelect` fill, 1px `OutlineShadow` border, 10px radius.
- 10x10 status dot at (16, 10), 1px black border, 4px radius.
- Label at left 30px, top 8px, Inter SemiBold 14px, `#0d0d0d`.
- Count at left 16px, top 30px, Inter SemiBold 24px, black.

| Card | Label | Dot color | Sample count |
|---|---|---|---|
| ActivePass | Total | Green `#66cd4c` | 01 |
| ReturnedPass | Present | Yellow `#ffde7c` | 15 |
| OverduePass | Absent | Red `#f24e51` | 01 |

Layer names (ActivePass, ReturnedPass, OverduePass) are left over from the pass screens, so don't use them as code names.

### 5.4 Analytics card

- Heading "Analytics", Inter Bold 26px, `#040404`.
- Card: 354x418, `MobileBackground` fill, 1px `OutlineShadow` border, 10px radius.
- Padding 42px horizontal, 20px vertical. Content stacked and centered with 4px gap.

**Donut chart (268x220 area)**
- Three segments with thin white separators, drawn clockwise from 12 o'clock (read from the screenshot):

| Segment | Color | Sample value | Share (of 82) |
|---|---|---|---|
| Top-right | `light Brown` `#6e473b` | 20 | about 24% |
| Bottom-right | `Pale Brown` `#a78d78` | 20 | about 24% |
| Left (large) | `Mist` `#beb5a9` | 42 | about 51% |

- Outer diameter is about 194px. The hole is roughly half of the outer diameter (estimated from the screenshot, not given in the metadata).
- Each segment has a thin leader line pointing to a value label outside the ring: "20" top-right, "20" bottom-right, "42" left. Labels are Inter Regular 12px, `#b4b4b4`.
- The segments are exported as static vector groups in Figma. In code, draw them from data instead of using the exported images (see section 8).

**Legend (students and label)**
- Column, 233px wide, 8px gap, items aligned to the right.
- Caption "Students": Inter Medium 14px, sits above the count column at the right.
- Three rows (Total, Present, Absent), each 32px tall with 7px horizontal padding:
  - Left: 12x12 square (`#d2d1d1`, 2px radius), 24px gap, label in Inter SemiBold 14px.
  - Right: count in Inter SemiBold 16px, pushed to the right edge (the gap between label and count differs per row only so the counts align; use space-between).

### 5.5 Students section

Identical to the "Sheets Issued" section in SupplementSheet, with the heading changed to "Students" (Inter SemiBold 26/32).

**Search bar:** 354x55, `TableRowInteraction` fill, 1px `OutlineShadow` border, 15px radius, 34x34 magnifier icon at left 12px, placeholder "Search for the students" (Inter Medium 16px).

**Student row:** 354x55, 12px gap between rows, `TableRowInteraction` fill, 1px `OutlineShadow` border, 15px radius.

| Element | Position | Style | Sample text |
|---|---|---|---|
| Student name | left 18, top 9 | Inter Medium 16 | Lorem Ipsum Dorem |
| Meta line | left 18, top 36 | Inter Medium 10 | B.tech \| 3rd Year \| 7045 |
| Count | left 316, top 7 | Inter Medium 20 | 01 |
| Status pill | left 286, top 33, 60x15 | `#d9d9d9`, 15px radius | Resolved |
| Pill text | left 299, top 37 | Inter Medium 8 | Resolved |

---

## 6. Assets

| Asset | Where | Size | Export from |
|---|---|---|---|
| Chevron back | Header | 30x30 | Frame `513:222` |
| Attendance icon glyph (bar chart) | Header circle | inside 40x40 | Group `513:227` inside frame `513:226` |
| Up/down chevron | Course selector | 24x24 | Frame `353:187` |
| Search magnifier | Search bar | 34x34 | Frame `512:98` |

The chart's vector groups and leader lines do not need exporting if you draw the donut in code.

---

## 7. Behavior Notes (inferred from the design)

- Chevron navigates back to the Teacher home.
- Course selector changes the course; counts, chart and list update with it.
- Search filters the student list.
- The three status cards and the chart both summarize attendance for the selected course.
- Only the "Resolved" row status is designed. For attendance, rows may eventually need Present / Absent states.

---

## 8. Build Notes

- **Reuse from SupplementSheet:** the header, status card, search bar and student row are almost the same. Give `SupplementsHeader` a title and icon parameter, and give `StatusCard` its own width. Don't copy them.
- **Draw the donut with a Compose `Canvas`** (`drawArc` with a stroke) from a list of values and colors. It will match changing data, which the exported SVG groups can't.
- The screen is 1086px tall, so it needs to scroll (`LazyColumn` or `verticalScroll`).

---

## 9. Observations and Open Questions

- **Sample data is inconsistent:** the cards show 01 / 15 / 01, the chart values are 42 / 20 / 20, and every legend count is 42. All of it is placeholder. Decide what each chart segment represents (probably Present vs Absent, possibly Total).
- **Legend swatches are all grey** (`#d2d1d1`) and don't match the three segment colors, so the legend doesn't currently identify the segments. Probably they should use `light Brown`, `Pale Brown` and `Mist`.
- **Status cards overflow slightly:** 3 x 110 + 2 x 12 = 354, but the container is 350, so the cards sit 4px wider than their container (the first card starts at x = -2).
- **Row rectangles** are 358px wide inside a 354px container (same quirk as SupplementSheet).
- **Heading weights differ:** "Analytics" is Bold and "Students" is SemiBold at the same size.
- The orange icon fill and status dot colors are not tokenized.
