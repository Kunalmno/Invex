# Circulars list and Circular page (Teacher, bottom sheets over Dashboard)

Source: your two screenshots + circulars.xml + CircularsWithSpecificLink.xml (390 x 844) + `ic_pdf.svg`. Figma MCP unavailable, so values marked (est.) come from the screenshots.

## How they open (Dashboard)
- Tap the **"Circulars"** heading on the Dashboard -> the **list** sheet.
- Tap a **circular row** on the Dashboard or inside the list -> that circular's own page.
- Swipe down or tap outside: back to the Dashboard.
- Exactly the same flow as Broadcasts.

## Sheet, list, title
Identical to Broadcasts.md (shared code in `ui/components/InfoSheet.kt`: 58% high, SoftWhite, top radius 16, padding 20 / 28 top, Pixelify 36 title with orange underline, list rows with `ic_arrow_over` and black dividers). Title is "Circulars".

## Circular page
| Item | Value |
|---|---|
| Title | the circular heading |
| Body | Inter Medium 14 / 22, indent 24 left and 48 right, left aligned (was justified) |
| Attachment row | 32 below the body, 16 from the left. Orange tile 60 x 60, radius 16, `ic_pdf` 40 (light #F7F9F7 glyph). 16 gap. Text: "Attached Document" Inter Medium 10, file name Inter Medium 16, "Date : 17 August 2026, 10:10 AM" Inter Medium 10, 4 between lines |
| Footer | "Circulated By : Admin" Inter Medium 14, 28 below the attachment (24 below the body when there is no attachment) |

## The "specific link"
It is the attached document. Tapping the attachment row opens the file's link in whatever app handles it (browser or PDF viewer). A circular without an attachment simply has no row.

## Data
- Sample data in `CircularsViewModel` (ids c1 to c3, same as the Dashboard rows). The attachment `url` is empty for now, so tapping does nothing until the backend gives a real link. TODO: load from the backend; the date is a ready-made text for now.

## Open
- Downloading the PDF inside the app (instead of opening the link) is not designed.
- Several attachments on one circular: not designed (only one row is supported).
- No empty or loading states.
