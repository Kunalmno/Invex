# Settings (Teacher)

Source: your screenshot + settings.xml (390 x 844, bg #EBEBEB). Figma MCP unavailable, so values marked (est.) come from the screenshot.

## Layout
| Item | Value |
|---|---|
| Title | "Settings" Pixelify SemiBold 36, orange underline 4 / offset 4, 16 from the left. No back arrow |
| Rows | 2 rows, 48 high, gap 4, radius 8, list padding 8 (icon sits 16 from the screen edge), top gap 24 below the title |
| Row content | icon 32, gap 20, title Inter Medium 20 (est.), chevron `ic_chevron_right` 24 at the end |
| Icons | Account Information: orange circle 32 + black `ic_user_information` (20 x 24). Notifications: `ic_notification_bell` (circle is inside the drawable) |
| Pressed state | row fill #E8E8E8 (the filled "Notifications" row in the design) |
| LOG OUT | Inter SemiBold 16 (est.), uppercase, red = `WarningRed` (one red for the app), 36 below the rows |

## Behavior
- Account Information and Notifications: tap does nothing yet (screens not designed).
- LOG OUT goes to Login and clears the whole back stack (no confirmation dialog, none designed).
- The Figma frame has no bottom bar; code shows `FloatingBottomNavBar` with Settings selected, because the other tab screens have it and Settings is a tab. To remove it: `showBottomBar = false` in `SettingsScreen`.
- No ViewModel yet: the screen has no state (no toggles).
- Bottom bar Settings tab (all tab screens and Dashboard) now opens this screen.

## Open
- Account Information and Notifications screens; whether log out should ask for confirmation.
- Exact red of LOG OUT (screenshot looks a bit more saturated than #F24E51).

## Assets
Converted from your SVGs: `ic_notification_bell`, `ic_user_information`. The chevron reuses `ic_chevron_right` from Schedule.
