# Duties (Teacher)

Source: your screenshot + Duties.xml (390 x 928, bg #EBEBEB). Figma MCP unavailable, so values marked (estimate) come from the screenshot.

## Layout
| Item | Value |
|---|---|
| Header | shared `ScreenHeader`: chevron 32, orange circle 40 with briefcase (padding 6, estimate), "Duties" Pixelify SemiBold 36, orange underline |
| Tabs | "Upcoming" (selected, orange underline) / "Completed", Pixelify Medium 24 (estimate), gap 40, both black |
| Cards | width 358, radius 16, white, 1dp #E8E8E8 border, padding 12, gap between cards 24 |
| Rows | icon 16 + label (Inter Medium 14, #737373); values: Building Inter SemiBold 20, Date/Time Inter Bold 14; 12 between rows |
| Drawing | `ic_room_card_background`, 126 x 171, top right, flush to the card edge (position estimate) |
| Button | 48 high pill, #151515, door icon 32, "view full room seating" Pixelify Medium 14 (estimate) SoftWhite, white arrow circle 32 |
| Bottom bar | existing `FloatingBottomNavBar`, Duties tab selected, 16 from bottom |

## Behavior
- Tabs switch between upcoming and completed lists (completed is empty, empty-state text is not designed).
- Button opens Room View for that duty (currently the same Rooms screen for every duty).
- Bottom bar: Home returns to Dashboard; Schedule and Settings are TODO.
- Dashboard's Duties tab now opens this screen.

## Open
- Dashboard's default selected nav tab is DUTIES; it should probably be HOME.
- Per-duty room data is not passed to Room View yet.
