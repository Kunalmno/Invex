# Progress Bar View (Teacher Page)

Design spec for the **Progress Bar View** frame of the InvEx Figma file. It is a loading screen: the "InvEx" wordmark with a thin progress bar underneath.

- **Figma file:** InvEx (`UPA9x8osa59kxcwCNlfAAh`)
- **Node:** `489:307` (Teacher page > Progress Bar View)
- **Link:** https://www.figma.com/design/UPA9x8osa59kxcwCNlfAAh/InvEx?node-id=489-307
- **Purpose:** shown while the app loads (splash / loading state). It has no interactive elements.

---

## 1. Frame

| Property | Value |
|---|---|
| Size | 390 x 844 (mobile) |
| Background | `MobileBackground` `#ebebeb` (project-wide) |
| Border | 1px `OutlineShadow` `#e8e8e8` |
| Corner radius | 15px, content clipped |
| Layout | Vertical stack, centered both ways, 32px gap |
| Padding | 95px left and right, 352px top and bottom |

The content block (logo + bar) is centered on the screen. Measured from the top: logo at y 370 to 434, bar at y 466 to 474. The center of the block (y 422) is the center of the 844px screen.

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#ebebeb` | Screen background (it was `#f2f2f2` in Figma; decided `#ebebeb` for the entire project) |
| `OutlineShadow` | `#e8e8e8` | Frame border |
| `orange` | `#ed451f` | Progress fill |

Not tokenized in Figma (hard-coded values):

| Value | Used for |
|---|---|
| `#d9d9d9` | Progress track |
| `#000000` | Wordmark text |

---

## 3. Typography

| Use | Font | Weight | Size / Line height |
|---|---|---|---|
| "InvEx" wordmark | Pixelify Sans | SemiBold | 64 / 64, black, no underline |

---

## 4. Layout Structure

```
Progress Bar View (489:307)             390x844, centered column, 32px gap
├── Logo (603:194)                       174x64
│   └── TextLogo (603:195)               "InvEx"
└── Frame 14 (488:306)                   200x8 progress track
    └── Rectangle 94 (271:129)           65x8 progress fill
```

---

## 5. Components

### 5.1 Wordmark

- Text "InvEx" in Pixelify Sans SemiBold 64px, line height 64px, black.
- Box is 174 x 64 and horizontally centered. It is plain text; there is no logo image or icon.

### 5.2 Progress bar

| Part | Size | Fill | Radius |
|---|---|---|---|
| Track | 200 x 8 | `#d9d9d9` | 4px |
| Fill | 64 x 8 (demo) | `orange` `#ed451f` | 4px |

- The track is centered horizontally and sits 32px below the wordmark.
- The fill starts at the left end of the track. Figma shows 65px, which is only a demo of how the bar looks while loading. It was rounded to 64px (32%) to follow the 4px grid. The real value comes from loading progress, 0 to 100%.
- Both ends use the same 4px radius (Figma had square track ends and a 3px fill).

---

## 6. Assets

None. The screen is text, two rectangles and a background. It uses the Pixelify Sans SemiBold font, which the project already has.

---

## 7. Behavior Notes

- Shown at app start while loading, before the first real screen.
- The orange fill grows from left to right as loading progresses, then the app moves on to the next screen.
- No user interaction.

---

## 8. Build Notes

- Compose: `Column` centered in the screen with 32dp spacing, a `Text` for the wordmark and a 200 x 8dp track `Box` with a fill `Box` using `fillMaxWidth(progress)`. The fill animates with `animateFloatAsState`.
- The bar is 200dp wide on every screen size, centered.

---

## 9. Resolved Decisions

| # | Question | Decision |
|---|---|---|
| 1 | Background `#f2f2f2` vs `#ebebeb` | `MobileBackground` is `#ebebeb` for the entire project. |
| 2 | Uneven corners | Follow the 4px rule: 4px radius on both the track and the fill. |
| 3 | Static progress | Yes, 65px was only to show how the bar looks once coded. Rounded to 64px on the grid. |
| 4 | "Status bar" note | Meant the phone's own top bar (clock, battery). The frame doesn't draw one, and none is needed. The content is centered on the full screen height. |
| 5 | Default layer names | Renamed in Figma: `Frame 14` is now `ProgressTrack` and `Rectangle 94` is now `ProgressFill` (ids `488:306`, `271:129`). |
