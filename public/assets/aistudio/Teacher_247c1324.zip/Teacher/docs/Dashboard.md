# Dashboard (Teacher Page)

Design spec for the **Dashboard** (Home) frame of the InvEx mobile application.

- **Sources:** 
  - Layout & Vector exports: `c:\Users\abc\Downloads\Dashboard\` (`Dashboard.xml`, `Heading.xml`, `notification.xml`, `todayDuty.xml`, `GlobalMessage.xml`, `Circulars and Broadcasts.xml`, `floatingNavigation.xml`, `floatingNavigationIconsDetails.xml`)
  - Screenshot reference: `Dashboard.png` / `media_1794208767889_5bcacd96.png`
  - Icon assets: `c:\Users\abc\Saved Games\Notes\Invex\DashboardIcon\` (mirrored in `Teacher/icons/`)
- **Node Context:** Teacher / Faculty Main Dashboard
- **Purpose:** Teacher-facing home screen providing immediate situational awareness: greeting with duty readiness status, daily exam duty count with room chip shortcuts, live active duty card (with hall info, countdown timer, visual timeline, and room navigation), one-tap runner/medical dispatch button, announcement feeds (Broadcasts and Circulars), and a persistent floating bottom navigation bar.

---

## 1. Frame

| Property | Value |
|---|---|
| Size | 390 x 1336 dp (tall mobile screen; content scrolls vertically) |
| Background | `MobileBackground` `#EBEBEB` |
| Border | 2px `OutlineShadow` `#E8E8E8` |
| Corner radius | 15dp |
| Layout | Vertical scrollable column (`LazyColumn` or `verticalScroll`) |
| Padding | ~40–48dp top, 11–16dp horizontal, ~96–110dp bottom (ensures content scrolls fully above the 80dp floating navigation bar) |
| Section Gap | 20dp – 24dp vertical spacing between major cards |

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#EBEBEB` | Screen background |
| `OutlineShadow` | `#E8E8E8` | Outer frame border, card borders, room chip strokes, divider lines |
| `TableRowInteraction` | `#FAFAFA` | Card fills: Today's Duty card, Broadcasts card, Circulars card |
| `Orange` | `#ED451F` | Accent color: "your duty begins" text, section title underline bars, active timeline dot, progress fill, Emergency Medical Call button |
| `IconColor` | `#171717` | Hero headline text ("Stay ready,"), icon tints |
| `PillGrey` | `#CCCCCC` / `#D9D9D9` | Floating navigation bar background (`#CCCCCC`), countdown timer badge fill (`#D9D9D9`), timeline inactive track |
| `TableHeaderText` / `MutedText` | `#737373` | Notification subhead ("You have 2 exam's duty today"), course ID, timeline labels ("Start", "End"), inactive tab icons/labels |
| `SectionHeadingColor` | `#000000` / `#040404` | Section titles ("Today's Duty", "Broadcasts", "Circulars"), hall names, room labels |
| `SoftWhite` | `#FFFFFF` / `#F7F9F7` | Text on orange emergency button, text on black "View Your Rooms" button, active navigation icon & label |

### Hard-coded / Non-tokenized Values in Layout Exports:

| Value | Used for |
|---|---|
| `#000000` | Active bottom navigation item badge (60x60 rounded square), "View Your Rooms" button fill |
| `#151515` | "view ↗" feed action link color |
| `#FAFAFA` | Today's duty card fill (`todayDuty.xml`) |
| `#CCCCCC` | Floating bottom navigation bar fill (`floatingNavigation.xml`) |
| `#ED451F` | Emergency Medical Call button background (`GlobalMessage.xml`) |

---

## 3. Typography

| Element | Font Family | Weight | Size / Line Height | Color / Style | Notes |
|---|---|---|---|---|---|
| **Hero Line 1** ("Stay ready,") | Pixelify Sans | SemiBold | 32sp / 40sp | `#171717`, letterSpacing -0.06 | Line 1 of hero greeting |
| **Hero Line 2** ("your [briefcase] duty begins.") | Pixelify Sans | SemiBold | 32sp / 40sp | `#ED451F`, letterSpacing -0.06 | Contains inline briefcase badge |
| **Duty Counter Subhead** ("You have 2 exam’s duty today") | Inter | Medium | 16sp / 18sp | `#737373`, letterSpacing -0.05 | Overview caption |
| **Room Chip Badge** ("B - 317") | Inter | Bold | 14sp / 16sp | `#000000` | Centered under desk icon in 100x100 chip |
| **Section Headings** ("Today’s Duty", "Broadcasts", "Circulars") | Pixelify Sans | SemiBold | 32sp / 32sp | `#000000`, letterSpacing -0.03 | Rendered with an orange `#ED451F` underline bar |
| **Examination Hall Name** ("Examination Hall A") | Inter | Bold | 20sp / 24sp | `#000000` | Card primary title |
| **Countdown Badge** ("0H 15 M") | Inter | SemiBold | 11sp / 14sp | `#000000` | Inside grey rounded pill with clock icon |
| **Course ID** ("Course Id : 1234567890") | Inter | Regular | 12sp / 16sp | `#737373` | Sub-label under hall name |
| **Timeline Labels** ("Start", "End") | Inter | Medium | 12sp / 14sp | `#737373` | Above start and end times |
| **Timeline Times** ("09:00", "10:00") | Inter | Bold | 24sp / 28sp | `#000000` | Big digital clock times |
| **Duty Progress Label** ("1 / 2 Duty completed") | Inter | Medium | 12sp / 14sp | `#000000` | Accompanied by orange indicator box |
| **"View Your Rooms" Button** | Inter | SemiBold | 16sp / 20sp | `#FFFFFF` | Inside black pill; "Rooms" underlined |
| **In-Seat Assistance Left** ("In-Seat Assistance") | Inter | SemiBold | 13sp / 18sp | `#000000` | Header of dispatch runner section |
| **In-Seat Assistance Right** ("Tap to Dispatch Runner") | Inter | Medium | 12sp / 18sp | `#737373` | Trailing hint on dispatch divider |
| **Emergency Call Button** ("Emergency Medical Call") | Inter | Bold | 16sp / 20sp | `#FFFFFF` | Inside orange button; "Medical" underlined |
| **Feed Row Heading** ("Heading One") | Inter | SemiBold | 13sp / 16sp | `#000000` | Underlined item title |
| **Feed Row Description** ("Lorem ipsum dolor...") | Inter | Regular | 10sp / 14sp | `#737373` | Truncated single-line preview |
| **Feed Row Link** ("view ↗") | Inter | Medium | 10sp / 12sp | `#151515` | Trailing action link with arrow |
| **Bottom Bar Active Tab** ("Duties") | Inter | Medium | 11sp / 12sp | `#FFFFFF` | Inside black rounded square badge |
| **Bottom Bar Inactive Tab** ("Home", "Schedule", "Settings") | Inter | Medium | 11sp / 12sp | `#737373` | Grey text under inactive icon |

---

## 4. Layout Structure

```
Dashboard (390 x 1336 dp)
├── Hero Greeting Section (358 x 80 dp)
│   ├── Line 1: "Stay ready,"                          (Pixelify Sans SemiBold 32sp, #171717)
│   └── Line 2: "your " + Briefcase Icon + " duty begins." (Pixelify Sans SemiBold 32sp, #ED451F)
│       └── Inline Badge: White rounded rect with black border + ic_business_briefcase.svg
├── Duty Notification & Room Chips (366 x 136 dp)
│   ├── Subtitle: "You have 2 exam’s duty today"       (Inter Medium 16sp, #737373)
│   └── Room Chips Row (366 x 100 dp, horizontal row, 16dp gap)
│       ├── Room Chip 1 (100 x 100 dp circle card, #FFFFFF, 1px border)
│       │   ├── Black circular desk icon badge (ic_notification.svg)
│       │   └── Label: "B - 317"                       (Inter Bold 14sp)
│       └── Room Chip 2 (100 x 100 dp circle card, #FFFFFF, 1px border)
│           ├── Black circular desk icon badge (ic_notification.svg)
│           └── Label: "B - 317"                       (Inter Bold 14sp)
├── Today's Duty Section (368 x 278 dp)
│   ├── Section Header: "Today’s Duty"                 (Pixelify Sans 32sp + orange underline bar)
│   └── Duty Card (368 x 228 dp, #FAFAFA, radius 15dp)
│       ├── Header Row (Hall Name + Countdown Badge)
│       │   ├── Hall Name: "Examination Hall A"        (Inter Bold 20sp)
│       │   │   └── Subtitle: "Course Id : 1234567890" (Inter Regular 12sp, #737373)
│       │   └── Countdown Pill: "⏱ 0H 15 M"           (radius 10dp, #D9D9D9 fill)
│       ├── Timeline Row (Start/End Times + Visual Track)
│       │   ├── Start Block: "Start" + "09:00"
│       │   ├── Start Node: Orange filled circle (#ED451F)
│       │   ├── Connecting Track: Dotted / dashed line
│       │   ├── Center Node: Arched Door Glyph (ic_door.svg)
│       │   ├── Connecting Track: Dotted / dashed line
│       │   ├── End Node: Hollow circular ring
│       │   └── End Block: "End" + "10:00"
│       ├── Duty Progress Bar
│       │   ├── Progress Track: 2-tone bar (left half #ED451F, right half #E8E8E8 / white)
│       │   └── Counter: Orange square swatch + "1 / 2 Duty completed" (Inter 12sp)
│       └── Action Button: "View Your Rooms" (336 x 48 dp, black pill, radius 24dp)
│           ├── Leading Icon: Door in arched frame (ic_door.svg, white)
│           ├── Label: "View Your Rooms" (white, "Rooms" underlined)
│           └── Trailing Icon: White circular badge with curved arrow (↩ / ➔)
├── In-Seat Assistance & Emergency Section (369 x 74 dp)
│   ├── Section Header / Divider Line
│   │   ├── Title: "In-Seat Assistance"                (Inter SemiBold 13sp)
│   │   ├── Horizontal Divider Bar                      (1px #E8E8E8)
│   │   └── Hint: "Tap to Dispatch Runner"             (Inter Medium 12sp, #737373)
│   └── Emergency Button (369 x 48 dp, radius 10dp, #ED451F fill)
│       ├── Leading Icon: Flashing beacon / siren (ic_alert_siren.svg, white)
│       └── Label: "Emergency Medical Call"            (Inter Bold 16sp, white, "Medical" underlined)
├── Broadcasts Section (371 x 214 dp)
│   ├── Section Header: "Broadcasts"                   (Pixelify Sans 32sp + orange underline bar)
│   └── Broadcasts Card (371 x 170 dp, #FAFAFA, radius 15dp, 3 rows, 1px divider between rows)
│       ├── Row 1 (Sound Icon): "Heading One" (underlined) | "Lorem ipsum..." | "view ↗"
│       ├── Row 2 (Alert Icon): "Heading One" (underlined) | "Lorem ipsum..." | "view ↗"
│       └── Row 3 (Flag Icon):  "Heading One" (underlined) | "Lorem ipsum..." | "view ↗"
├── Circulars Section (371 x 214 dp)
│   ├── Section Header: "Circulars"                    (Pixelify Sans 32sp + orange underline bar)
│   └── Circulars Card (371 x 170 dp, #FAFAFA, radius 15dp, 3 rows, 1px divider between rows)
│       ├── Row 1 (Sound Icon): "Heading One" (underlined) | "Lorem ipsum..." | "view ↗"
│       ├── Row 2 (Alert Icon): "Heading One" (underlined) | "Lorem ipsum..." | "view ↗"
│       └── Row 3 (Flag Icon):  "Heading One" (underlined) | "Lorem ipsum..." | "view ↗"
└── Floating Bottom Navigation Bar (358 x 80 dp, floating overlay, pinned to bottom)
    └── Pill Container (358 x 80 dp, radius 30dp, fill #CCCCCC, 4 tab items)
        ├── Tab 1: Home     (ic_home.svg, "Home", inactive #737373)
        ├── Tab 2: Duties   (Active: 60x60 #000000 rounded square badge, ic_duties_Icon.svg, "Duties", white #FFFFFF)
        ├── Tab 3: Schedule (ic_schedule.svg, "Schedule", inactive #737373)
        └── Tab 4: Settings (ic_settings.svg, "Settings", inactive #737373)
```

---

## 5. Component Specifications

### 5.1 Hero Greeting & Briefcase Inline Badge
- **Container:** 358dp wide x 80dp high.
- **Line 1:** `"Stay ready,"` in Pixelify Sans SemiBold 32sp, color `#171717`.
- **Line 2:** Formatted inline row containing:
  - Text `"your"` in Pixelify Sans SemiBold 32sp, color `Orange` (`#ED451F`).
  - Inline briefcase chip: 35x36dp white badge with rounded corners and 1.5px black border, enclosing `ic_business_briefcase.svg`.
  - Text `"duty begins."` in Pixelify Sans SemiBold 32sp, color `Orange` (`#ED451F`).

### 5.2 Duty Notification & Room Chips
- **Container:** 366dp wide.
- **Header Caption:** `"You have 2 exam’s duty today"` in Inter Medium 16sp, color `#737373`, letter-spacing -0.05.
- **Room Badges Row:** Horizontal arrangement, 16dp gap between chips.
  - Each Chip: 100x100dp circular card, `#FFFFFF` fill, 1px `OutlineShadow` `#E8E8E8` stroke.
  - Center contents:
    - Upper: 60x60dp circular black glyph (`ic_notification.svg`) depicting the classroom/exam hall desk.
    - Lower: Room ID text `"B - 317"` in Inter Bold 14sp, `#000000`.
  - Interactive: Tapping a chip opens the detail view for that assigned examination hall.

### 5.3 Today's Duty Section & Card
- **Section Heading:** `"Today’s Duty"` in Pixelify Sans SemiBold 32sp, `#000000`. Underlined by an orange accent bar (thickness 3dp, offset 4dp) using `LineUnderlinedText`.
- **Card Container:** 368dp wide x 228dp high, `#FAFAFA` fill, 15dp corner radius, 1px `OutlineShadow` border, 16dp internal padding.
- **Hall Details & Live Timer:**
  - Left: `"Examination Hall A"` (Inter Bold 20sp, `#000000`) and `"Course Id : 1234567890"` (Inter Regular 12sp, `#737373`).
  - Right: Countdown pill with clock icon and `"0H 15 M"` (Inter SemiBold 11sp, background `#D9D9D9`, corner radius 10dp, padding 4dp horizontal x 2dp vertical).
- **Timeline Row:**
  - Displays `"Start"` (Inter Medium 12sp, `#737373`) above `"09:00"` (Inter Bold 24sp, `#000000`).
  - Solid orange circular node (`#ED451F`, 10dp diameter).
  - Dotted horizontal timeline bar.
  - Center door glyph: `ic_door.svg` inside arched frame (24x24dp).
  - Dotted horizontal timeline bar.
  - Hollow circular ring node (10dp diameter, 2dp black border).
  - Displays `"End"` (Inter Medium 12sp, `#737373`) above `"10:00"` (Inter Bold 24sp, `#000000`).
- **Progress Row:**
  - A 4dp high progress bar: filled portion is `Orange` (`#ED451F`), remaining track is `#E8E8E8`.
  - Below/beside: A small orange square indicator swatch next to `"1 / 2 Duty completed"` in Inter Medium 12sp (`#000000`).
- **Action Button ("View Your Rooms"):**
  - Full width pill button (height 48dp, background `#000000`, corner radius 24dp).
  - Content: Arched door icon (`ic_door.svg`, white), text `"View Your Rooms"` (Inter SemiBold 16sp, white, `"Rooms"` underlined), and a trailing white circular badge with an enter/return arrow icon.

### 5.4 In-Seat Assistance & Emergency Medical Call
- **Container:** 369dp wide x 74dp high.
- **Header Line:**
  - Left: `"In-Seat Assistance"` in Inter SemiBold 13sp (`#000000`).
  - Center: Horizontal hairline divider (`#E8E8E8`).
  - Right: `"Tap to Dispatch Runner"` in Inter Medium 12sp (`#737373`).
- **Emergency Button:**
  - Dimensions: 369dp wide x 48dp high, corner radius 10dp, background `Orange` (`#ED451F`).
  - Leading Icon: Flashing beacon / siren icon (`ic_alert_siren.svg`, 32x32dp, white).
  - Label: `"Emergency Medical Call"` in Inter Bold 16sp, white; `"Medical"` has a solid white underline.
  - Action: Immediate SOS dispatch triggering runner assistance to the teacher's active examination room.

### 5.5 Broadcasts & Circulars Feed Cards
Both sections follow an identical card list pattern:

- **Section Header:** `"Broadcasts"` and `"Circulars"` in Pixelify Sans SemiBold 32sp, `#000000`, with an orange underline bar (`LineUnderlinedText`).
- **Card Container:** 371dp wide x 214dp high (or wrap content), `#FAFAFA` fill, 15dp corner radius, 1px `OutlineShadow` border.
- **Feed Item Rows:** 3 items per card (height 44dp each), separated by 1px `#E8E8E8` horizontal dividers:
  - **Leading Icon:** 24x24dp icon tinted `#000000` / `#171717`:
    - Row 1: Megaphone / sound glyph (`ic_sound.svg`).
    - Row 2: Alert exclamation inside circle (`ic_alert_circle.svg`).
    - Row 3: Pennant flag glyph (`ic_flag.svg`).
  - **Content Column:**
    - Title: `"Heading One"` in Inter SemiBold 13sp (`#000000`, underlined).
    - Description: `"Lorem ipsum dolor sit amet, consectetur elit..."` in Inter Regular 10sp (`#737373`), single-line ellipsis.
  - **Trailing Action:**
    - `"view ↗"` in Inter Medium 10sp, color `#151515`, clickable to open notice detail dialog or sheet.

### 5.6 Floating Bottom Navigation Bar
- **Container:** 358dp wide x 80dp high, floating overlay centered horizontally at the bottom of the screen with ~16dp bottom offset.
- **Pill Shape:** Corner radius 30dp (pill-shaped), background `#CCCCCC`.
- **Tabs (4 items):**
  1. **Home:** `ic_home.svg` (30x30dp) + `"Home"` label (Inter Medium 11sp, color `#737373`).
  2. **Duties (Active Tab):**
     - Highlight Container: 60x60dp rounded square badge (`#000000`, corner radius 16dp).
     - Icon: `ic_duties_Icon.svg` (double doors, 30x30dp, tinted `#FFFFFF`).
     - Label: `"Duties"` (Inter Medium 11sp, color `#FFFFFF`).
  3. **Schedule:** `ic_schedule.svg` (30x30dp) + `"Schedule"` label (Inter Medium 11sp, color `#737373`).
  4. **Settings:** `ic_settings.svg` (30x30dp) + `"Settings"` label (Inter Medium 11sp, color `#737373`).

---

## 6. Assets & Icons Mapping

All icons are located in `Teacher/icons/` and `c:\Users\abc\Saved Games\Notes\Invex\DashboardIcon\`:

| Asset File | Size | Used for | Visual Description |
|---|---|---|---|
| `ic_business_briefcase.svg` | 35 x 36 dp | Hero greeting line 2 | Briefcase glyph inside a white badge |
| `ic_notification.svg` | 60 x 60 dp | Room chips (B - 317) | Isometric classroom / exam desks & board in black circle |
| `ic_door.svg` | 30 x 30 dp | Duty timeline & "View Your Rooms" button | Arched entrance doorway with panels |
| `ic_alert_siren.svg` | 40 x 40 dp | Emergency Medical Call button | Rotating siren / beacon with flashing rays |
| `ic_sound.svg` | 30 x 30 dp | Broadcasts & Circulars row 1 | Speaker / megaphone horn with audio waves |
| `ic_alert_circle.svg` | 30 x 30 dp | Broadcasts & Circulars row 2 | Exclamation mark inside a circular border |
| `ic_flag.svg` | 30 x 30 dp | Broadcasts & Circulars row 3 | Flag on a flagpole |
| `ic_home.svg` | 30 x 30 dp | Floating bottom bar tab 1 | Outline house icon |
| `ic_duties_Icon.svg` | 30 x 30 dp | Floating bottom bar tab 2 (Duties) | Double exam hall doors with window frames |
| `ic_schedule.svg` | 30 x 30 dp | Floating bottom bar tab 3 | Calendar with grid and binding rings |
| `ic_settings.svg` | 30 x 30 dp | Floating bottom bar tab 4 | Cog / gear wheel |

---

## 7. Behavior & Interaction Notes

1. **Scroll & Navigation Visibility:**
   - The screen content scrolls behind the persistent floating navigation bar. The scroll container must include bottom content padding of at least `96.dp` so that the last Circulars card is never occluded by the navigation pill.
2. **Duty Room Navigation:**
   - Tapping either the room chips (`B - 317`) or the `"View Your Rooms"` button navigates the teacher to the Room Roster / Attendance screen (`AttendanceScreen.kt`).
3. **Live Countdown Timer:**
   - The countdown pill (`"0H 15 M"`) should tick down dynamically based on the current system time compared to the active duty's end time (`10:00`).
4. **Emergency Medical Call Dispatch:**
   - Tapping `"Emergency Medical Call"` triggers an urgent confirmation prompt ("Dispatch medical runner to Hall A?") to prevent accidental triggers, followed by real-time dispatch tracking.
5. **Notice Viewing:**
   - Tapping `"view ↗"` or any row in Broadcasts or Circulars launches a full-screen or bottom-sheet notice viewer showing the complete message text, attachments, and issuing department.
6. **Floating Navigation Tab Switch:**
   - Switching tabs moves the black highlighted active badge (60x60dp) with an animated spring transition between the 4 tab positions.

---

## 8. Build Notes (Jetpack Compose Implementation)

- **Layout Structure:**
  ```kotlin
  Box(modifier = Modifier.fillMaxSize().background(MobileBackground)) {
      LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 100.dp),
          verticalArrangement = Arrangement.spacedBy(20.dp)
      ) {
          item { HeroGreetingSection() }
          item { DutyNotificationAndRoomChips() }
          item { TodayDutyCard() }
          item { EmergencyAssistanceSection() }
          item { BroadcastsSection() }
          item { CircularsSection() }
      }
      FloatingBottomNavigationBar(
          modifier = Modifier
              .align(Alignment.BottomCenter)
              .padding(bottom = 16.dp)
      )
  }
  ```
- **Reuse Existing Components:**
  - Use `LineUnderlinedText` from `com.invex.app.ui.components.LineUnderlinedText` for the section headers (`"Today’s Duty"`, `"Broadcasts"`, `"Circulars"`).
  - Use color tokens from `com.invex.app.ui.theme.Color.kt` (`MobileBackground`, `OutlineShadow`, `Orange`, `TableRowInteraction`, etc.).
  - Add text styles to `InvexType` in `Type.kt` for the specific font variations.

---

## 9. Observations & Open Questions

- **Width Variations in XML:**
  - The XML exports have slight width variations: `Dashboard.xml` is 390dp, `heading` is 358dp, `notificatio` is 366dp, `today_duty_` is 368dp, `emergencyvi` is 369dp, `circulars` is 371dp, and `flotainbott` is 358dp.
  - In Jetpack Compose, all cards should use `Modifier.fillMaxWidth()` with a consistent `16.dp` horizontal parent padding (yielding an effective width of 358dp on a 390dp screen) for visual symmetry and alignment.
- **Font Sizes in XML:**
  - Some text views in the raw XML exports specify very small sizes (e.g. `8sp` in `Circulars and Broadcasts.xml`). In Jetpack Compose, use standard readable scales: `13.sp` for row titles, `10.sp`–`11.sp` for metadata/descriptions, and `11.sp` for bottom navigation labels.
- **Room Badges Dynamic Count:**
  - The design shows two identical `"B - 317"` chips corresponding to `"You have 2 exam’s duty today"`. In production, this should be a horizontal scrollable row or flow row mapped to the teacher's actual scheduled rooms for the day.
- **Bottom Navigation Integration:**
  - Confirm whether the floating navigation bar is shared across all top-level teacher screens (Home, Duties/Attendance, Schedule, Settings) or specific to the dashboard.
