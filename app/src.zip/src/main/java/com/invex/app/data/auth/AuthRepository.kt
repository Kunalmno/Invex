package com.invex.app.data.auth

import com.invex.app.login.UserRole
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.exception.AuthRestException
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.CancellationException

/**
 * Login with a Faculty ID / Student ID and a password.
 * Supabase logs in with an email, so the ID is turned into `<id in lower case>@invex.app`
 * (the same rule used when the admin creates the user; see Backend.md).
 */
class AuthRepository(private val client: SupabaseClient) {

    suspend fun login(role: UserRole, id: String, password: String): LoginResult {
        val cleanId = id.trim()
        if (cleanId.isEmpty() || password.isEmpty()) {
            return LoginResult.Failure("Enter your ${role.idLabel} and password")
        }
        return try {
            client.auth.signInWith(Email) {
                this.email = emailFor(cleanId)
                this.password = password
            }
            val profile = loadProfile()
            when {
                profile == null -> {
                    client.auth.signOut()
                    LoginResult.Failure("This account is not set up yet. Contact the admin.")
                }
                profile.role != role.dbValue -> {
                    client.auth.signOut()
                    LoginResult.Failure("This ID is not a ${role.label} account")
                }
                else -> LoginResult.Success(profile)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: AuthRestException) {
            LoginResult.Failure("Wrong ${role.idLabel} or password")
        } catch (e: Exception) {
            LoginResult.Failure("Could not reach the server. Check your internet connection and try again.")
        }
    }

    /** Called when the app starts: the saved login, if there is one. Null means "show Onboarding / Login". */
    suspend fun restoreSession(): UserProfile? {
        client.auth.awaitInitialization()
        if (client.auth.currentSessionOrNull() == null) return null
        return try {
            loadProfile()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    suspend fun logout() {
        try {
            client.auth.signOut()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Offline: the local session is still cleared by the library on the next start.
        }
    }

    private suspend fun loadProfile(): UserProfile? {
        val userId = client.auth.currentUserOrNull()?.id ?: return null
        return client.from("profiles")
            .select { filter { eq("id", userId) } }
            .decodeSingleOrNull<UserProfile>()
    }

    private fun emailFor(id: String) = "${id.lowercase()}@invex.app"
}
