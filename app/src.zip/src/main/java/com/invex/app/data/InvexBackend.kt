package com.invex.app.data

import com.invex.app.BuildConfig
import com.invex.app.data.auth.AuthRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest

/**
 * The one connection to Supabase for the whole app.
 * The URL and the public (anon / publishable) key come from local.properties through BuildConfig,
 * so they are not typed into the code. Never put the service_role key in the app.
 */
object InvexBackend {
    val client: SupabaseClient by lazy {
        createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_ANON_KEY,
        ) {
            install(Auth)      // login; the session is saved on the phone
            install(Postgrest) // tables, views and functions
        }
    }

    val auth: AuthRepository by lazy { AuthRepository(client) }
}
